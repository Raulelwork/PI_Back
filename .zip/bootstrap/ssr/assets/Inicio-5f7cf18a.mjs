import { mergeProps, withCtx, createVNode, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr } from "vue/server-renderer";
import { _ as _imports_0 } from "./logopng-0a2f9f34.mjs";
import { L as Layout } from "./Layout-57e2f8e0.mjs";
import { Link } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./ResponsiveNavLink-c8aee0e1.mjs";
import "./_plugin-vue_export-helper-cc2b3d55.mjs";
const Inicio_vue_vue_type_style_index_0_lang = "";
const __default__ = {
  components: { NavLink: _sfc_main$1, Link },
  data() {
    return {
      showMenu: false
    };
  }
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  __name: "Inicio",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ id: "fondo " }, _attrs))}>`);
      _push(ssrRenderComponent(Layout, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="text-center text-white"${_scopeId}><h1 class="text-4xl mt-16 mb-36 max-[1288px]:bg-black/70"${_scopeId}>Bienvenido a Party Time</h1><img id="animate-spin-slow" class="animate-spin mx-auto block w-96 max-[750px]:w-60"${ssrRenderAttr("src", _imports_0)} alt="logo"${_scopeId}><div class="mt-40 text-2xl text-white bg-pink-900/40 mx-96 max-[900px]:mx-0 rounded-md" id="texto"${_scopeId}><p${_scopeId}>Reserva ya tu entrada y no te quedes fuera!</p></div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$1, {
              href: "/fiestas",
              class: "no-underline hover:no-underline"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<button class="mt-10 mb-20 border-2 rounded-md bg-pink-900/80 hover:bg-pink-800/80 text-white hover:scale-110 duration-200 p-1" id="enlace"${_scopeId2}> IR A FIESTAS </button>`);
                } else {
                  return [
                    createVNode("button", {
                      class: "mt-10 mb-20 border-2 rounded-md bg-pink-900/80 hover:bg-pink-800/80 text-white hover:scale-110 duration-200 p-1",
                      id: "enlace"
                    }, " IR A FIESTAS ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "text-center text-white" }, [
                createVNode("h1", { class: "text-4xl mt-16 mb-36 max-[1288px]:bg-black/70" }, "Bienvenido a Party Time"),
                createVNode("img", {
                  id: "animate-spin-slow",
                  class: "animate-spin mx-auto block w-96 max-[750px]:w-60",
                  src: _imports_0,
                  alt: "logo"
                }),
                createVNode("div", {
                  class: "mt-40 text-2xl text-white bg-pink-900/40 mx-96 max-[900px]:mx-0 rounded-md",
                  id: "texto"
                }, [
                  createVNode("p", null, "Reserva ya tu entrada y no te quedes fuera!")
                ]),
                createVNode("div", null, [
                  createVNode(_sfc_main$1, {
                    href: "/fiestas",
                    class: "no-underline hover:no-underline"
                  }, {
                    default: withCtx(() => [
                      createVNode("button", {
                        class: "mt-10 mb-20 border-2 rounded-md bg-pink-900/80 hover:bg-pink-800/80 text-white hover:scale-110 duration-200 p-1",
                        id: "enlace"
                      }, " IR A FIESTAS ")
                    ]),
                    _: 1
                  })
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Inicio.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
