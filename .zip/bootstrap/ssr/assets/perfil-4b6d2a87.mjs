import { Swiper, SwiperSlide } from "swiper/vue";
/* empty css                      */import { Autoplay, Pagination, Navigation } from "swiper";
import { Link } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./ResponsiveNavLink-c8aee0e1.mjs";
import { L as Layout } from "./Layout-57e2f8e0.mjs";
import Swal from "sweetalert2";
import { resolveComponent, mergeProps, withCtx, createTextVNode, createVNode, toDisplayString, openBlock, createBlock, Fragment, renderList, withDirectives, vModelText, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrRenderList, ssrRenderClass } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import "./logopng-0a2f9f34.mjs";
const perfil_vue_vue_type_style_index_0_lang = "";
const _sfc_main = {
  components: {
    Swiper,
    SwiperSlide,
    Layout,
    NavLink: _sfc_main$1,
    Link
  },
  data() {
    return {
      showMenu: false,
      color: ["text-blue-600", "text-pink-600", "text-red-600", "text-green-600", "text-orange-600", "text-yellow-600", "text-violet-600"],
      contcomentario: ""
    };
  },
  props: {
    empresa: Object,
    fiestas: []
  },
  methods: {
    enviar(id_ent) {
      const id = id_ent;
      axios.post("/hacerreserva", {
        "id_entrada": id
      }).then((response) => {
        this.showAlert();
      }).catch((error) => {
      });
    },
    showAlert() {
      Swal.fire({
        title: "Reserva Realizada!",
        text: "Puedes visualizar la reserva en MIS RESERVAS.",
        icon: "success",
        confirmButtonColor: "#1a202c"
      });
    },
    showAlertComentario() {
      Swal.fire({
        title: "Comentario Realizada!",
        text: "Tu comentario se ha realizado correctamente.",
        icon: "success",
        confirmButtonColor: "#1a202c"
      });
    },
    comentar() {
      axios.post("/insertacomentario", {
        "contenido": this.contcomentario,
        "id_empresa": this.empresa.id
      }).then((response) => {
        this.contcomentario = "";
        this.showAlertComentario();
        this.empresa.comentarios.push(response.data);
      }).catch((error) => {
      });
    },
    formatdate(dateTimeString) {
      return this.formatearFecha(dateTimeString.slice(0, 10));
    },
    formatearFecha(fecha) {
      const dateObj = new Date(fecha);
      const dia = dateObj.getDate().toString().padStart(2, "0");
      const mes = (dateObj.getMonth() + 1).toString().padStart(2, "0");
      const anio = dateObj.getFullYear().toString();
      return `${dia}-${mes}-${anio}`;
    },
    orderByDate: function(fiestas) {
      return fiestas.sort(function(a, b) {
        return new Date(a.fecha) - new Date(b.fecha);
      });
    },
    orderByDateComent: function(fiestas) {
      return fiestas.sort(function(a, b) {
        return new Date(b.fecha) - new Date(a.fecha);
      });
    }
  },
  setup() {
    return {
      modules: [Autoplay, Pagination, Navigation]
    };
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Layout = resolveComponent("Layout");
  const _component_nav_link = resolveComponent("nav-link");
  const _component_swiper = resolveComponent("swiper");
  const _component_swiper_slide = resolveComponent("swiper-slide");
  _push(`<section${ssrRenderAttrs(mergeProps({ class: "entradas" }, _attrs))}>`);
  _push(ssrRenderComponent(_component_Layout, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<section class="fondolog"${_scopeId}><h1 class="text-7xl text-center text-white pt-14 mb-12"${_scopeId}>${ssrInterpolate($props.empresa.nombre)}</h1><div class="flex flex-wrap justify-center items-center text-center text-white"${_scopeId}><div class="max-w-xl bg-gray-800/80 rounded-md m-12"${_scopeId}><img${ssrRenderAttr("src", "https://pipartytime.com/storage/empresas/" + $props.empresa.foto)} class="md:max-w-sm max-h-sm object-cover md:p-12" alt="foto perfil"${_scopeId}></div><div class="w-96 h-80 bg-gray-800/90 rounded-md"${_scopeId}><h2 class="text-2xl mt-2 mb-3"${_scopeId}>Comentarios</h2><div class="overflow-y-auto h-44 mx-4 break-words text-justify"${_scopeId}><!--[-->`);
        ssrRenderList($options.orderByDateComent($props.empresa.comentarios), (comentario) => {
          _push2(`<div${_scopeId}><p class="${ssrRenderClass($data.color[Math.floor(Math.random() * 6)] + " text-lg")}"${_scopeId}>${ssrInterpolate(comentario.nombreusuario)}</p><p class="text-white"${_scopeId}>${ssrInterpolate(comentario.contenido)}</p></div>`);
        });
        _push2(`<!--]--></div>`);
        if (_ctx.$page.props.auth.user) {
          _push2(`<div class="flex flex-col border-t-2 border-white/50"${_scopeId}><input type="text" class="bg-gray-50/0 text-center pt-4" placeholder="Escribir aqui... "${ssrRenderAttr("value", $data.contcomentario)}${_scopeId}><button class="mt-2 transition duration-300 hover:scale-110"${_scopeId}>Comentar</button></div>`);
        } else {
          _push2(`<div class="pt-4 mt-6 border-t-2 border-white/50"${_scopeId}> Se requiere `);
          _push2(ssrRenderComponent(_component_nav_link, {
            class: "linkEntrada",
            href: "/login"
          }, {
            default: withCtx((_2, _push3, _parent3, _scopeId2) => {
              if (_push3) {
                _push3(`Inicia Sesion`);
              } else {
                return [
                  createTextVNode("Inicia Sesion")
                ];
              }
            }),
            _: 1
          }, _parent2, _scopeId));
          _push2(` para comentar <p${_scopeId}></p></div>`);
        }
        _push2(`</div></div></section><div class="divUno"${_scopeId}><h1 class="text-white text-3xl text-center"${_scopeId}>ENTRADAS</h1><div class="divDos"${_scopeId}><!--[-->`);
        ssrRenderList($options.orderByDate($props.fiestas), (fiesta) => {
          _push2(`<div class="divFiesta"${_scopeId}><img${ssrRenderAttr("src", "https://pipartytime.com/storage/fiestas/" + fiesta.foto)} class="imgFiesta" alt=""${_scopeId}><h1 class="h1Fiesta text-pink-600"${_scopeId}>${ssrInterpolate(fiesta.empresa.nombre)} -&gt; ${ssrInterpolate($options.formatdate(fiesta.fecha))}</h1><div class="contentFiesta"${_scopeId}><p${_scopeId}>Musica:</p><p${_scopeId}>${ssrInterpolate(fiesta.musica.nombre)}</p><p${_scopeId}>Tematica:</p><p${_scopeId}>${ssrInterpolate(fiesta.tematica.nombre)}</p></div><div class="m-2"${_scopeId}><h1 class="h1Fiesta"${_scopeId}>ENTRADAS</h1>`);
          if (!_ctx.$page.props.auth.user) {
            _push2(`<p class="entradaFiesta"${_scopeId}>Se requiere `);
            _push2(ssrRenderComponent(_component_nav_link, {
              class: "linkEntrada",
              href: "/login"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Inicia Sesion`);
                } else {
                  return [
                    createTextVNode("Inicia Sesion")
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(` para reservar </p>`);
          } else if (fiesta.entrada.length > 0) {
            _push2(ssrRenderComponent(_component_swiper, {
              spaceBetween: 30,
              centeredSlides: true,
              autoplay: {
                delay: 4500,
                disableOnInteraction: false
              },
              pagination: false,
              navigation: false,
              modules: $setup.modules
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<!--[-->`);
                  ssrRenderList(fiesta.entrada, (e) => {
                    _push3(ssrRenderComponent(_component_swiper_slide, {
                      class: "mySwiper swiperEntrada",
                      key: e.id
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`<p class="${ssrRenderClass($data.color[Math.floor(Math.random() * 6)] + " text-lg")}"${_scopeId3}>${ssrInterpolate(e.tipo)}</p><p class="m-2"${_scopeId3}>${ssrInterpolate(e.consumiciones)} Copas </p><p class="m-2"${_scopeId3}>${ssrInterpolate(e.precio)}€ </p><div class="reservaEntrada"${_scopeId3}><button${_scopeId3}>Reservar</button></div>`);
                        } else {
                          return [
                            createVNode("p", {
                              class: $data.color[Math.floor(Math.random() * 6)] + " text-lg"
                            }, toDisplayString(e.tipo), 3),
                            createVNode("p", { class: "m-2" }, toDisplayString(e.consumiciones) + " Copas ", 1),
                            createVNode("p", { class: "m-2" }, toDisplayString(e.precio) + "€ ", 1),
                            createVNode("div", { class: "reservaEntrada" }, [
                              createVNode("button", {
                                onClick: ($event) => $options.enviar(e.id)
                              }, "Reservar", 8, ["onClick"])
                            ])
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                  });
                  _push3(`<!--]-->`);
                } else {
                  return [
                    (openBlock(true), createBlock(Fragment, null, renderList(fiesta.entrada, (e) => {
                      return openBlock(), createBlock(_component_swiper_slide, {
                        class: "mySwiper swiperEntrada",
                        key: e.id
                      }, {
                        default: withCtx(() => [
                          createVNode("p", {
                            class: $data.color[Math.floor(Math.random() * 6)] + " text-lg"
                          }, toDisplayString(e.tipo), 3),
                          createVNode("p", { class: "m-2" }, toDisplayString(e.consumiciones) + " Copas ", 1),
                          createVNode("p", { class: "m-2" }, toDisplayString(e.precio) + "€ ", 1),
                          createVNode("div", { class: "reservaEntrada" }, [
                            createVNode("button", {
                              onClick: ($event) => $options.enviar(e.id)
                            }, "Reservar", 8, ["onClick"])
                          ])
                        ]),
                        _: 2
                      }, 1024);
                    }), 128))
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
          } else {
            _push2(`<p class="noDisponible"${_scopeId}>No hay entradas disponibles</p>`);
          }
          _push2(`</div></div>`);
        });
        _push2(`<!--]--></div></div>`);
      } else {
        return [
          createVNode("section", { class: "fondolog" }, [
            createVNode("h1", { class: "text-7xl text-center text-white pt-14 mb-12" }, toDisplayString($props.empresa.nombre), 1),
            createVNode("div", { class: "flex flex-wrap justify-center items-center text-center text-white" }, [
              createVNode("div", { class: "max-w-xl bg-gray-800/80 rounded-md m-12" }, [
                createVNode("img", {
                  src: "https://pipartytime.com/storage/empresas/" + $props.empresa.foto,
                  class: "md:max-w-sm max-h-sm object-cover md:p-12",
                  alt: "foto perfil"
                }, null, 8, ["src"])
              ]),
              createVNode("div", { class: "w-96 h-80 bg-gray-800/90 rounded-md" }, [
                createVNode("h2", { class: "text-2xl mt-2 mb-3" }, "Comentarios"),
                createVNode("div", { class: "overflow-y-auto h-44 mx-4 break-words text-justify" }, [
                  (openBlock(true), createBlock(Fragment, null, renderList($options.orderByDateComent($props.empresa.comentarios), (comentario) => {
                    return openBlock(), createBlock("div", {
                      key: comentario.id
                    }, [
                      createVNode("p", {
                        class: $data.color[Math.floor(Math.random() * 6)] + " text-lg"
                      }, toDisplayString(comentario.nombreusuario), 3),
                      createVNode("p", { class: "text-white" }, toDisplayString(comentario.contenido), 1)
                    ]);
                  }), 128))
                ]),
                _ctx.$page.props.auth.user ? (openBlock(), createBlock("div", {
                  key: 0,
                  class: "flex flex-col border-t-2 border-white/50"
                }, [
                  withDirectives(createVNode("input", {
                    type: "text",
                    class: "bg-gray-50/0 text-center pt-4",
                    placeholder: "Escribir aqui... ",
                    "onUpdate:modelValue": ($event) => $data.contcomentario = $event
                  }, null, 8, ["onUpdate:modelValue"]), [
                    [vModelText, $data.contcomentario]
                  ]),
                  createVNode("button", {
                    onClick: $options.comentar,
                    class: "mt-2 transition duration-300 hover:scale-110"
                  }, "Comentar", 8, ["onClick"])
                ])) : (openBlock(), createBlock("div", {
                  key: 1,
                  class: "pt-4 mt-6 border-t-2 border-white/50"
                }, [
                  createTextVNode(" Se requiere "),
                  createVNode(_component_nav_link, {
                    class: "linkEntrada",
                    href: "/login"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Inicia Sesion")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" para comentar "),
                  createVNode("p")
                ]))
              ])
            ])
          ]),
          createVNode("div", { class: "divUno" }, [
            createVNode("h1", { class: "text-white text-3xl text-center" }, "ENTRADAS"),
            createVNode("div", { class: "divDos" }, [
              (openBlock(true), createBlock(Fragment, null, renderList($options.orderByDate($props.fiestas), (fiesta) => {
                return openBlock(), createBlock("div", {
                  class: "divFiesta",
                  key: fiesta.id
                }, [
                  createVNode("img", {
                    src: "https://pipartytime.com/storage/fiestas/" + fiesta.foto,
                    class: "imgFiesta",
                    alt: ""
                  }, null, 8, ["src"]),
                  createVNode("h1", { class: "h1Fiesta text-pink-600" }, toDisplayString(fiesta.empresa.nombre) + " -> " + toDisplayString($options.formatdate(fiesta.fecha)), 1),
                  createVNode("div", { class: "contentFiesta" }, [
                    createVNode("p", null, "Musica:"),
                    createVNode("p", null, toDisplayString(fiesta.musica.nombre), 1),
                    createVNode("p", null, "Tematica:"),
                    createVNode("p", null, toDisplayString(fiesta.tematica.nombre), 1)
                  ]),
                  createVNode("div", { class: "m-2" }, [
                    createVNode("h1", { class: "h1Fiesta" }, "ENTRADAS"),
                    !_ctx.$page.props.auth.user ? (openBlock(), createBlock("p", {
                      key: 0,
                      class: "entradaFiesta"
                    }, [
                      createTextVNode("Se requiere "),
                      createVNode(_component_nav_link, {
                        class: "linkEntrada",
                        href: "/login"
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Inicia Sesion")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" para reservar ")
                    ])) : fiesta.entrada.length > 0 ? (openBlock(), createBlock(_component_swiper, {
                      key: 1,
                      spaceBetween: 30,
                      centeredSlides: true,
                      autoplay: {
                        delay: 4500,
                        disableOnInteraction: false
                      },
                      pagination: false,
                      navigation: false,
                      modules: $setup.modules
                    }, {
                      default: withCtx(() => [
                        (openBlock(true), createBlock(Fragment, null, renderList(fiesta.entrada, (e) => {
                          return openBlock(), createBlock(_component_swiper_slide, {
                            class: "mySwiper swiperEntrada",
                            key: e.id
                          }, {
                            default: withCtx(() => [
                              createVNode("p", {
                                class: $data.color[Math.floor(Math.random() * 6)] + " text-lg"
                              }, toDisplayString(e.tipo), 3),
                              createVNode("p", { class: "m-2" }, toDisplayString(e.consumiciones) + " Copas ", 1),
                              createVNode("p", { class: "m-2" }, toDisplayString(e.precio) + "€ ", 1),
                              createVNode("div", { class: "reservaEntrada" }, [
                                createVNode("button", {
                                  onClick: ($event) => $options.enviar(e.id)
                                }, "Reservar", 8, ["onClick"])
                              ])
                            ]),
                            _: 2
                          }, 1024);
                        }), 128))
                      ]),
                      _: 2
                    }, 1032, ["modules"])) : (openBlock(), createBlock("p", {
                      key: 2,
                      class: "noDisponible"
                    }, "No hay entradas disponibles"))
                  ])
                ]);
              }), 128))
            ])
          ])
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</section>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/perfil.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const perfil = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  perfil as default
};
