import { mergeProps, withCtx, createVNode, withDirectives, vModelText, withModifiers, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr } from "vue/server-renderer";
import { L as Layout } from "./Layout-57e2f8e0.mjs";
import { Link } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./ResponsiveNavLink-c8aee0e1.mjs";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import "./logopng-0a2f9f34.mjs";
const addcontent_vue_vue_type_style_index_0_scoped_a46399e5_lang = "";
const __default__ = {
  components: { NavLink: _sfc_main$1, Link },
  data() {
    return {
      showMenu: false,
      nombreMusica: "",
      nombreTematica: ""
    };
  },
  methods: {
    enviarmusica() {
      const formData = new FormData();
      formData.append("nombre", this.nombreMusica);
      axios.post("/crearmusica", formData, {
        headers: {
          "Content-Type": "multipart/form-data"
        }
      }).then((response) => {
      }).catch((error) => {
      });
    },
    enviartematica() {
      const formData = new FormData();
      formData.append("nombre", this.nombreTematica);
      axios.post("/creartematica", formData, {
        headers: {
          "Content-Type": "multipart/form-data"
        }
      }).then((response) => {
      }).catch((error) => {
      });
    }
  }
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  __name: "addcontent",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "fondolog" }, _attrs))} data-v-a46399e5>`);
      _push(ssrRenderComponent(Layout, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<section class="flex justify-center mt-14" data-v-a46399e5${_scopeId}><div class="max-w-md justify-center text-white text-center mt-8 m-4 bg-gray-800/90 rounded-md p-12" data-v-a46399e5${_scopeId}><h1 class="text-3xl text-white" data-v-a46399e5${_scopeId}>Crear Musica</h1><form action="" data-v-a46399e5${_scopeId}><div class="m-2" data-v-a46399e5${_scopeId}><label for="Nombre" data-v-a46399e5${_scopeId}>Nombre</label><br data-v-a46399e5${_scopeId}><input class="w-48 h-8 rounded-md text-gray-300 bg-gray-600 text-center placeholder:text-gray-400 hover:scale-105 duration-200" type="text"${ssrRenderAttr("value", _ctx.nombreMusica)} data-v-a46399e5${_scopeId}></div><button class="decoration-0 m-4 px-3 py-2 border-2 rounded-md bg-pink-900/80 hover:bg-pink-800/80 text-white hover:scale-110 duration-200" data-v-a46399e5${_scopeId}>Crear Musica</button></form></div><div class="max-w-md justify-center text-white text-center mt-8 m-4 bg-gray-800/90 rounded-md p-12" data-v-a46399e5${_scopeId}><h1 class="text-3xl text-white" data-v-a46399e5${_scopeId}>Crear Tematica</h1><form action="" data-v-a46399e5${_scopeId}><div class="m-2" data-v-a46399e5${_scopeId}><label for="Nombre" data-v-a46399e5${_scopeId}>Nombre</label><br data-v-a46399e5${_scopeId}><input class="w-48 h-8 rounded-md text-gray-300 bg-gray-600 text-center placeholder:text-gray-400 hover:scale-105 duration-200" type="text"${ssrRenderAttr("value", _ctx.nombreTematica)} data-v-a46399e5${_scopeId}></div><button class="decoration-0 m-4 px-3 py-2 border-2 rounded-md bg-pink-900/80 hover:bg-pink-800/80 text-white hover:scale-110 duration-200" data-v-a46399e5${_scopeId}>Crear Tematica</button></form></div></section>`);
          } else {
            return [
              createVNode("section", { class: "flex justify-center mt-14" }, [
                createVNode("div", { class: "max-w-md justify-center text-white text-center mt-8 m-4 bg-gray-800/90 rounded-md p-12" }, [
                  createVNode("h1", { class: "text-3xl text-white" }, "Crear Musica"),
                  createVNode("form", { action: "" }, [
                    createVNode("div", { class: "m-2" }, [
                      createVNode("label", { for: "Nombre" }, "Nombre"),
                      createVNode("br"),
                      withDirectives(createVNode("input", {
                        class: "w-48 h-8 rounded-md text-gray-300 bg-gray-600 text-center placeholder:text-gray-400 hover:scale-105 duration-200",
                        type: "text",
                        "onUpdate:modelValue": ($event) => _ctx.nombreMusica = $event
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, _ctx.nombreMusica]
                      ])
                    ]),
                    createVNode("button", {
                      class: "decoration-0 m-4 px-3 py-2 border-2 rounded-md bg-pink-900/80 hover:bg-pink-800/80 text-white hover:scale-110 duration-200",
                      onClick: withModifiers(_ctx.enviarmusica, ["prevent"])
                    }, "Crear Musica", 8, ["onClick"])
                  ])
                ]),
                createVNode("div", { class: "max-w-md justify-center text-white text-center mt-8 m-4 bg-gray-800/90 rounded-md p-12" }, [
                  createVNode("h1", { class: "text-3xl text-white" }, "Crear Tematica"),
                  createVNode("form", { action: "" }, [
                    createVNode("div", { class: "m-2" }, [
                      createVNode("label", { for: "Nombre" }, "Nombre"),
                      createVNode("br"),
                      withDirectives(createVNode("input", {
                        class: "w-48 h-8 rounded-md text-gray-300 bg-gray-600 text-center placeholder:text-gray-400 hover:scale-105 duration-200",
                        type: "text",
                        "onUpdate:modelValue": ($event) => _ctx.nombreTematica = $event
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, _ctx.nombreTematica]
                      ])
                    ]),
                    createVNode("button", {
                      class: "decoration-0 m-4 px-3 py-2 border-2 rounded-md bg-pink-900/80 hover:bg-pink-800/80 text-white hover:scale-110 duration-200",
                      onClick: withModifiers(_ctx.enviartematica, ["prevent"])
                    }, "Crear Tematica", 8, ["onClick"])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</section>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/addcontent.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const addcontent = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-a46399e5"]]);
export {
  addcontent as default
};
