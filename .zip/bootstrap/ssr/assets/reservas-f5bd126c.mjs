import { Link } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./ResponsiveNavLink-c8aee0e1.mjs";
import { L as Layout } from "./Layout-57e2f8e0.mjs";
import { ref, resolveComponent, mergeProps, withCtx, createVNode, openBlock, createBlock, Fragment, renderList, toDisplayString, useSSRContext } from "vue";
import Swal from "sweetalert2";
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrRenderAttr, ssrInterpolate } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import "./logopng-0a2f9f34.mjs";
const _imports_0 = "/build/assets/no-738a5702.png";
const reservas_vue_vue_type_style_index_0_lang = "";
const _sfc_main = {
  components: { NavLink: _sfc_main$1, Link, Layout, ref },
  data() {
    return {
      showMenu: false,
      entradas: []
    };
  },
  mounted() {
    axios.get("/reservasdeusuario").then((response) => {
      this.entradas = response.data;
    }).catch((error) => {
    });
  },
  methods: {
    showAlert() {
      Swal.fire({
        title: "Reserva Eliminada!",
        text: "Tu reserva se ha eliminado con exito.",
        icon: "success",
        confirmButtonColor: "#1a202c"
      });
    },
    eliminar(array) {
      const id = array[1];
      const id_entrada = array[0];
      axios.post("/eliminarreserva", {
        "id": id,
        "id_entrada": id_entrada
      }).then((response) => {
        for (var i = 0; i < this.entradas.length; i++) {
          if (this.entradas[i].idreserva == id) {
            this.entradas.splice(i, 1);
          }
        }
        this.showAlert();
      }).catch((error) => {
      });
    },
    formatdate(dateTimeString) {
      return this.formatearFecha(dateTimeString.slice(0, 10));
    },
    formatearFecha(fecha) {
      const dateObj = new Date(fecha);
      const dia = dateObj.getDate().toString().padStart(2, "0");
      const mes = (dateObj.getMonth() + 1).toString().padStart(2, "0");
      const anio = dateObj.getFullYear().toString();
      return `${dia}-${mes}-${anio}`;
    },
    orderByDate: function(entradas) {
      return entradas.sort(function(a, b) {
        return new Date(a.fecha) - new Date(b.fecha);
      });
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Layout = resolveComponent("Layout");
  _push(`<section${ssrRenderAttrs(mergeProps({ class: "fondoreserva" }, _attrs))}>`);
  _push(ssrRenderComponent(_component_Layout, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<div class="min-[450px]:grid place-items-center border-t-black"${_scopeId}><div class="flex flex-wrap justify-center min-[1400px]:grid min-[1400px]:grid-cols-4"${_scopeId}><!--[-->`);
        ssrRenderList($options.orderByDate($data.entradas), (entrada) => {
          _push2(`<div class="bg-white/90 max-w-sm rounded-t-xl overflow-hidden shadow-lg m-7 max-[450px]:scale-75"${_scopeId}><img${ssrRenderAttr("src", "https://pipartytime.com/storage/fiestas/" + entrada.foto)} class="mb-4 w-full h-80 object-cover" alt=""${_scopeId}><h1 class="text-lg text-center"${_scopeId}>${ssrInterpolate(entrada.nombreempresa)} -&gt; ${ssrInterpolate($options.formatdate(entrada.fecha))}</h1><div class="grid grid-cols-2 text-left text-black justify-items-center items-center"${_scopeId}><p${_scopeId}>Tipo Entrada:</p><p${_scopeId}>${ssrInterpolate(entrada.tipo)}</p><p${_scopeId}>Consumiciones:</p><p${_scopeId}>${ssrInterpolate(entrada.consumiciones)}</p><p${_scopeId}>Precio:</p><p${_scopeId}>${ssrInterpolate(entrada.precio)}€</p><p${_scopeId}>Musica:</p><p${_scopeId}>${ssrInterpolate(entrada.musica)}</p><p${_scopeId}>Tematica:</p><p${_scopeId}>${ssrInterpolate(entrada.tematica)}</p></div><div class="m-2 text-center"${_scopeId}><button class="rounded-md transition duration-300 hover:scale-125"${_scopeId}><img${ssrRenderAttr("src", _imports_0)} class="w-12 m-4" alt="Cancelar"${_scopeId}></button></div></div>`);
        });
        _push2(`<!--]--></div></div>`);
      } else {
        return [
          createVNode("div", { class: "min-[450px]:grid place-items-center border-t-black" }, [
            createVNode("div", { class: "flex flex-wrap justify-center min-[1400px]:grid min-[1400px]:grid-cols-4" }, [
              (openBlock(true), createBlock(Fragment, null, renderList($options.orderByDate($data.entradas), (entrada) => {
                return openBlock(), createBlock("div", {
                  key: entrada.id,
                  class: "bg-white/90 max-w-sm rounded-t-xl overflow-hidden shadow-lg m-7 max-[450px]:scale-75"
                }, [
                  createVNode("img", {
                    src: "https://pipartytime.com/storage/fiestas/" + entrada.foto,
                    class: "mb-4 w-full h-80 object-cover",
                    alt: ""
                  }, null, 8, ["src"]),
                  createVNode("h1", { class: "text-lg text-center" }, toDisplayString(entrada.nombreempresa) + " -> " + toDisplayString($options.formatdate(entrada.fecha)), 1),
                  createVNode("div", { class: "grid grid-cols-2 text-left text-black justify-items-center items-center" }, [
                    createVNode("p", null, "Tipo Entrada:"),
                    createVNode("p", null, toDisplayString(entrada.tipo), 1),
                    createVNode("p", null, "Consumiciones:"),
                    createVNode("p", null, toDisplayString(entrada.consumiciones), 1),
                    createVNode("p", null, "Precio:"),
                    createVNode("p", null, toDisplayString(entrada.precio) + "€", 1),
                    createVNode("p", null, "Musica:"),
                    createVNode("p", null, toDisplayString(entrada.musica), 1),
                    createVNode("p", null, "Tematica:"),
                    createVNode("p", null, toDisplayString(entrada.tematica), 1)
                  ]),
                  createVNode("div", { class: "m-2 text-center" }, [
                    createVNode("button", {
                      onClick: ($event) => $options.eliminar([entrada.id, entrada.idreserva]),
                      class: "rounded-md transition duration-300 hover:scale-125"
                    }, [
                      createVNode("img", {
                        src: _imports_0,
                        class: "w-12 m-4",
                        alt: "Cancelar"
                      })
                    ], 8, ["onClick"])
                  ])
                ]);
              }), 128))
            ])
          ])
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</section>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/reservas.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const reservas = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  reservas as default
};
