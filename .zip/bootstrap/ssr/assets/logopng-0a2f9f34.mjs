const _imports_0 = "/build/assets/logopng-c6567aa7.png";
export {
  _imports_0 as _
};
