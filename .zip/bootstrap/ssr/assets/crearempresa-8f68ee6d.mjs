import { Link } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./ResponsiveNavLink-c8aee0e1.mjs";
import { L as Layout } from "./Layout-57e2f8e0.mjs";
import Swal from "sweetalert2";
import { resolveComponent, mergeProps, withCtx, createVNode, withModifiers, withDirectives, vModelText, vModelSelect, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import "./logopng-0a2f9f34.mjs";
const crearempresa_vue_vue_type_style_index_0_scoped_d5243e25_lang = "";
const _sfc_main = {
  components: { Layout, NavLink: _sfc_main$1, Link },
  data() {
    return {
      showMenu: false,
      nombree: "",
      cif: "",
      ubicacion: "",
      lugar: "",
      foto: null
    };
  },
  methods: {
    cargarFoto() {
      this.foto = this.$refs.fotoInput.files[0];
    },
    enviar() {
      const formData = new FormData();
      formData.append("foto", this.foto);
      formData.append("nombre", this.nombre);
      formData.append("cif", this.cif);
      formData.append("ubicacion", this.ubicacion);
      formData.append("lugar", this.lugar);
      axios.post("/crearempresa", formData, {
        headers: {
          "Content-Type": "multipart/form-data"
        }
      }).then((response) => {
        this.showAlert();
      }).catch((error) => {
        this.showAlertError();
      });
    },
    showAlert() {
      Swal.fire({
        title: "Empresa creada!",
        text: "Su empresa ha sido registrada con exito.",
        icon: "success",
        confirmButtonColor: "#1a202c"
      });
    },
    showAlertError() {
      Swal.fire({
        title: "Ha surgido un error",
        text: "Error inesperado. Intenta realizar esta operacion en unos minutos..",
        icon: "error",
        confirmButtonColor: "#1a202c"
      });
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Layout = resolveComponent("Layout");
  _push(`<section${ssrRenderAttrs(mergeProps({ class: "fondolog" }, _attrs))} data-v-d5243e25>`);
  _push(ssrRenderComponent(_component_Layout, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<section class="flex justify-center mt-14" data-v-d5243e25${_scopeId}><div class="max-w-md justify-center text-white text-center mt-8 bg-gray-800/90 rounded-md p-12" data-v-d5243e25${_scopeId}><h1 class="text-3xl text-white" data-v-d5243e25${_scopeId}>Crear Empresa</h1><form data-v-d5243e25${_scopeId}><div data-v-d5243e25${_scopeId}><label for="nombre" data-v-d5243e25${_scopeId}>Nombre</label><br data-v-d5243e25${_scopeId}><input class="w-48 h-8 rounded-md text-gray-300 bg-gray-600 text-center placeholder:text-gray-400 hover:scale-105 duration-200" type="text"${ssrRenderAttr("value", _ctx.nombre)} data-v-d5243e25${_scopeId}></div><div data-v-d5243e25${_scopeId}><label for="cif" data-v-d5243e25${_scopeId}>Cif</label><br data-v-d5243e25${_scopeId}><input class="w-48 h-8 rounded-md text-gray-300 bg-gray-600 text-center placeholder:text-gray-400 hover:scale-105 duration-200" type="text"${ssrRenderAttr("value", $data.cif)} data-v-d5243e25${_scopeId}></div><div data-v-d5243e25${_scopeId}><label for="ubicacion" data-v-d5243e25${_scopeId}>Ubicacion</label><br data-v-d5243e25${_scopeId}><select name="ubicacion" id="ubicacion" class="p-1 text-gray-300 rounded-md bg-gray-700" data-v-d5243e25${_scopeId}><option value="Almeria" data-v-d5243e25${_scopeId}>Almeria</option><option value="Granada" data-v-d5243e25${_scopeId}>Granada</option><option value="Malaga" data-v-d5243e25${_scopeId}>Malaga</option><option value="Sevilla" data-v-d5243e25${_scopeId}>Sevilla</option><option value="Cadiz" data-v-d5243e25${_scopeId}>Cadiz</option><option value="Huelva" data-v-d5243e25${_scopeId}>Huelva</option><option value="Cordoba" data-v-d5243e25${_scopeId}>Cordoba</option><option value="Jaen" data-v-d5243e25${_scopeId}>Jaen</option></select></div><div data-v-d5243e25${_scopeId}><label for="lugar" data-v-d5243e25${_scopeId}>Lugar</label><br data-v-d5243e25${_scopeId}><input class="w-48 h-8 rounded-md text-gray-300 bg-gray-600 text-center placeholder:text-gray-400 hover:scale-105 duration-200" type="text"${ssrRenderAttr("value", $data.lugar)} data-v-d5243e25${_scopeId}></div><div data-v-d5243e25${_scopeId}><label for="foto" data-v-d5243e25${_scopeId}>Foto:</label><br data-v-d5243e25${_scopeId}><input type="file" class="block w-full text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-gray-50 dark:text-gray-400 focus:outline-none dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400" id="foto" accept="image/*" data-v-d5243e25${_scopeId}></div><button class="decoration-0 m-4 px-3 py-2 border-2 rounded-md bg-pink-900/80 hover:bg-pink-800/80 text-white hover:scale-110 duration-200" data-v-d5243e25${_scopeId}>Enviar</button></form></div></section>`);
      } else {
        return [
          createVNode("section", { class: "flex justify-center mt-14" }, [
            createVNode("div", { class: "max-w-md justify-center text-white text-center mt-8 bg-gray-800/90 rounded-md p-12" }, [
              createVNode("h1", { class: "text-3xl text-white" }, "Crear Empresa"),
              createVNode("form", {
                onSubmit: withModifiers(_ctx.submit, ["prevent"])
              }, [
                createVNode("div", null, [
                  createVNode("label", { for: "nombre" }, "Nombre"),
                  createVNode("br"),
                  withDirectives(createVNode("input", {
                    class: "w-48 h-8 rounded-md text-gray-300 bg-gray-600 text-center placeholder:text-gray-400 hover:scale-105 duration-200",
                    type: "text",
                    "onUpdate:modelValue": ($event) => _ctx.nombre = $event
                  }, null, 8, ["onUpdate:modelValue"]), [
                    [vModelText, _ctx.nombre]
                  ])
                ]),
                createVNode("div", null, [
                  createVNode("label", { for: "cif" }, "Cif"),
                  createVNode("br"),
                  withDirectives(createVNode("input", {
                    class: "w-48 h-8 rounded-md text-gray-300 bg-gray-600 text-center placeholder:text-gray-400 hover:scale-105 duration-200",
                    type: "text",
                    "onUpdate:modelValue": ($event) => $data.cif = $event
                  }, null, 8, ["onUpdate:modelValue"]), [
                    [vModelText, $data.cif]
                  ])
                ]),
                createVNode("div", null, [
                  createVNode("label", { for: "ubicacion" }, "Ubicacion"),
                  createVNode("br"),
                  withDirectives(createVNode("select", {
                    name: "ubicacion",
                    "onUpdate:modelValue": ($event) => $data.ubicacion = $event,
                    id: "ubicacion",
                    class: "p-1 text-gray-300 rounded-md bg-gray-700"
                  }, [
                    createVNode("option", { value: "Almeria" }, "Almeria"),
                    createVNode("option", { value: "Granada" }, "Granada"),
                    createVNode("option", { value: "Malaga" }, "Malaga"),
                    createVNode("option", { value: "Sevilla" }, "Sevilla"),
                    createVNode("option", { value: "Cadiz" }, "Cadiz"),
                    createVNode("option", { value: "Huelva" }, "Huelva"),
                    createVNode("option", { value: "Cordoba" }, "Cordoba"),
                    createVNode("option", { value: "Jaen" }, "Jaen")
                  ], 8, ["onUpdate:modelValue"]), [
                    [vModelSelect, $data.ubicacion]
                  ])
                ]),
                createVNode("div", null, [
                  createVNode("label", { for: "lugar" }, "Lugar"),
                  createVNode("br"),
                  withDirectives(createVNode("input", {
                    class: "w-48 h-8 rounded-md text-gray-300 bg-gray-600 text-center placeholder:text-gray-400 hover:scale-105 duration-200",
                    type: "text",
                    "onUpdate:modelValue": ($event) => $data.lugar = $event
                  }, null, 8, ["onUpdate:modelValue"]), [
                    [vModelText, $data.lugar]
                  ])
                ]),
                createVNode("div", null, [
                  createVNode("label", { for: "foto" }, "Foto:"),
                  createVNode("br"),
                  createVNode("input", {
                    type: "file",
                    class: "block w-full text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-gray-50 dark:text-gray-400 focus:outline-none dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400",
                    id: "foto",
                    ref: "fotoInput",
                    onChange: $options.cargarFoto,
                    accept: "image/*"
                  }, null, 40, ["onChange"])
                ]),
                createVNode("button", {
                  class: "decoration-0 m-4 px-3 py-2 border-2 rounded-md bg-pink-900/80 hover:bg-pink-800/80 text-white hover:scale-110 duration-200",
                  onClick: withModifiers($options.enviar, ["prevent"])
                }, "Enviar", 8, ["onClick"])
              ], 40, ["onSubmit"])
            ])
          ])
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</section>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/crearempresa.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const crearempresa = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__scopeId", "data-v-d5243e25"]]);
export {
  crearempresa as default
};
