import { Link } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./ResponsiveNavLink-c8aee0e1.mjs";
import { L as Layout } from "./Layout-57e2f8e0.mjs";
import { resolveComponent, mergeProps, withCtx, createVNode, toDisplayString, withDirectives, vModelCheckbox, openBlock, createBlock, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrIncludeBooleanAttr, ssrLooseContain, ssrRenderList, ssrInterpolate, ssrRenderAttr } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import "./logopng-0a2f9f34.mjs";
const locales_vue_vue_type_style_index_0_lang = "";
const _sfc_main = {
  components: {
    Layout,
    NavLink: _sfc_main$1,
    Link
  },
  data() {
    return {
      showMenu: false,
      empresas: [],
      empresasFiltradas: [],
      filtros: [],
      ciudades: {
        almeria: false,
        granada: false,
        cadiz: false,
        cordoba: false,
        malaga: false,
        sevilla: false,
        huelva: false,
        jaen: false
      }
    };
  },
  mounted() {
    axios.get("/listarallempresas").then((response) => {
      this.empresas = response.data;
      this.empresasFiltradas = response.data;
    }).catch((error) => {
    });
  },
  methods: {
    filtrar() {
      this.empresasFiltradas = [];
      this.filtros = [];
      for (let ciudad in this.ciudades) {
        if (this.ciudades[ciudad]) {
          this.filtros.push(ciudad);
        }
      }
      if (this.filtros.length == 0) {
        this.empresasFiltradas = this.empresas;
      } else {
        for (let empresa in this.empresas) {
          if (this.filtros.includes(this.empresas[empresa].ubicacion.toLowerCase())) {
            this.empresasFiltradas.push(this.empresas[empresa]);
          }
        }
      }
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Layout = resolveComponent("Layout");
  const _component_nav_link = resolveComponent("nav-link");
  _push(`<section${ssrRenderAttrs(mergeProps({ class: "entradas" }, _attrs))}>`);
  _push(ssrRenderComponent(_component_Layout, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<h1 class="text-white p-3 rounded-sm text-5xl mt-4 max-[1120px]:mx-0 max-[1120px]:text-4xl text-center mx-96"${_scopeId}> LOCALES </h1><div class="hidden md:flex flex-col bg-black/70 rounded-br-xl float-left p-4"${_scopeId}><h1 class="text-white text-xl"${_scopeId}>Ciudades</h1><div class="flex flex-col m-2 text-blue-400 items-center"${_scopeId}><label for="sevilla"${_scopeId}>Sevilla</label><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray($data.ciudades["sevilla"]) ? ssrLooseContain($data.ciudades["sevilla"], null) : $data.ciudades["sevilla"]) ? " checked" : ""} id="sevilla" name="ciudad" class="mr-2 mt-1 ml-1 rounded-full p-2"${_scopeId}></div><div class="flex flex-col m-2 text-pink-400 items-center"${_scopeId}><label for="malaga"${_scopeId}>Málaga</label><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray($data.ciudades["malaga"]) ? ssrLooseContain($data.ciudades["malaga"], null) : $data.ciudades["malaga"]) ? " checked" : ""} id="malaga" name="ciudad" class="mx-2 mt-1 rounded-full p-2"${_scopeId}></div><div class="flex flex-col m-2 text-blue-400 items-center"${_scopeId}><label for="cadiz"${_scopeId}>Cádiz</label><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray($data.ciudades["cadiz"]) ? ssrLooseContain($data.ciudades["cadiz"], null) : $data.ciudades["cadiz"]) ? " checked" : ""} id="cadiz" name="ciudad" class="mx-2 mt-1 rounded-full p-2"${_scopeId}></div><div class="flex flex-col m-2 text-pink-400 items-center"${_scopeId}><label for="granada"${_scopeId}>Granada</label><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray($data.ciudades["granada"]) ? ssrLooseContain($data.ciudades["granada"], null) : $data.ciudades["granada"]) ? " checked" : ""} id="granada" name="ciudad" class="mx-2 mt-1 rounded-full p-2"${_scopeId}></div><div class="flex flex-col m-2 text-blue-400 items-center"${_scopeId}><label for="cordoba"${_scopeId}>Córdoba</label><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray($data.ciudades["cordoba"]) ? ssrLooseContain($data.ciudades["cordoba"], null) : $data.ciudades["cordoba"]) ? " checked" : ""} id="cordoba" name="ciudad" class="mx-2 mt-1 rounded-full p-2"${_scopeId}></div><div class="flex flex-col m-2 text-pink-400 items-center"${_scopeId}><label for="almeria"${_scopeId}>Almería</label><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray($data.ciudades["almeria"]) ? ssrLooseContain($data.ciudades["almeria"], null) : $data.ciudades["almeria"]) ? " checked" : ""} id="almeria" name="ciudad" class="mx-2 mt-1 rounded-full p-2"${_scopeId}></div><div class="flex flex-col m-2 text-blue-400 items-center"${_scopeId}><label for="huelva"${_scopeId}>Huelva</label><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray($data.ciudades["huelva"]) ? ssrLooseContain($data.ciudades["huelva"], null) : $data.ciudades["huelva"]) ? " checked" : ""} id="huelva" name="ciudad" class="mx-2 mt-1 rounded-full p-2"${_scopeId}></div><div class="flex flex-col m-2 text-pink-400 items-center"${_scopeId}><label for="jaen"${_scopeId}>Jaén</label><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray($data.ciudades["jaen"]) ? ssrLooseContain($data.ciudades["jaen"], null) : $data.ciudades["jaen"]) ? " checked" : ""} id="jaen" name="ciudad" class="mx-2 mt-1 rounded-full p-2"${_scopeId}></div></div><div class="dropdown text-white"${_scopeId}><button class="md:hidden dropbtn m-4"${_scopeId}>Filtros</button><div class="dropdown-content"${_scopeId}><div class="flex flex-col bg-black/70 rounded-br-xl float-left p-4"${_scopeId}><h1 class="text-white text-xl"${_scopeId}>Ciudades</h1><div class="m-2 text-blue-400 block inline-block"${_scopeId}><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray($data.ciudades["sevilla"]) ? ssrLooseContain($data.ciudades["sevilla"], null) : $data.ciudades["sevilla"]) ? " checked" : ""} id="sevilla" name="ciudad" class="mx-2 mt-1 rounded-full p-1"${_scopeId}><label for="sevilla"${_scopeId}>Sevilla</label></div><div class="m-2 text-pink-400 block inline-block"${_scopeId}><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray($data.ciudades["malaga"]) ? ssrLooseContain($data.ciudades["malaga"], null) : $data.ciudades["malaga"]) ? " checked" : ""} id="malaga" name="ciudad" class="mx-2 mt-1 rounded-full p-1"${_scopeId}><label for="malaga"${_scopeId}>Málaga</label></div><div class="m-2 text-blue-400 block inline-block"${_scopeId}><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray($data.ciudades["cadiz"]) ? ssrLooseContain($data.ciudades["cadiz"], null) : $data.ciudades["cadiz"]) ? " checked" : ""} id="cadiz" name="ciudad" class="mx-2 mt-1 rounded-full p-1"${_scopeId}><label for="cadiz"${_scopeId}>Cádiz</label></div><div class="m-2 text-pink-400 block inline-block"${_scopeId}><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray($data.ciudades["granada"]) ? ssrLooseContain($data.ciudades["granada"], null) : $data.ciudades["granada"]) ? " checked" : ""} id="granada" name="ciudad" class="mx-2 mt-1 rounded-full p-1"${_scopeId}><label for="granada"${_scopeId}>Granada</label></div><div class="m-2 text-blue-400 block inline-block"${_scopeId}><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray($data.ciudades["cordoba"]) ? ssrLooseContain($data.ciudades["cordoba"], null) : $data.ciudades["cordoba"]) ? " checked" : ""} id="cordoba" name="ciudad" class="mx-2 mt-1 rounded-full p-1"${_scopeId}><label for="cordoba"${_scopeId}>Córdoba</label></div><div class="m-2 text-pink-400 block inline-block"${_scopeId}><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray($data.ciudades["almeria"]) ? ssrLooseContain($data.ciudades["almeria"], null) : $data.ciudades["almeria"]) ? " checked" : ""} id="almeria" name="ciudad" class="mx-2 mt-1 rounded-full p-1"${_scopeId}><label for="almeria"${_scopeId}>Almería</label></div><div class="m-2 text-blue-400 block inline-block"${_scopeId}><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray($data.ciudades["huelva"]) ? ssrLooseContain($data.ciudades["huelva"], null) : $data.ciudades["huelva"]) ? " checked" : ""} id="huelva" name="ciudad" class="mx-2 mt-1 rounded-full p-1"${_scopeId}><label for="huelva"${_scopeId}>Huelva</label></div><div class="m-2 text-pink-400 block inline-block"${_scopeId}><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray($data.ciudades["jaen"]) ? ssrLooseContain($data.ciudades["jaen"], null) : $data.ciudades["jaen"]) ? " checked" : ""} id="jaen" name="ciudad" class="mx-2 mt-1 rounded-full p-1"${_scopeId}><label for="jaen"${_scopeId}>Jaén</label></div></div></div></div><div class="min-[450px]:grid place-items-center"${_scopeId}><div class="flex flex-wrap justify-center min-[1400px]:grid min-[1400px]:grid-cols-4"${_scopeId}><!--[-->`);
        ssrRenderList($data.empresasFiltradas, (empresa) => {
          _push2(`<div${_scopeId}>`);
          _push2(ssrRenderComponent(_component_nav_link, {
            href: "perfil/" + empresa.id,
            class: "no-underline"
          }, {
            default: withCtx((_2, _push3, _parent3, _scopeId2) => {
              if (_push3) {
                _push3(`<div class="bg-gray-300/20 max-w-sm rounded-sm overflow-hidden shadow-xl shadow-pink-600/40 m-7 p-4 transition duration-500 hover:scale-110"${_scopeId2}><h2 class="text-white text-4xl m-3 text-center"${_scopeId2}>${ssrInterpolate(empresa.nombre)}</h2><img${ssrRenderAttr("src", "https://pipartytime.com/storage/empresas/" + empresa.foto)} class="mb-4 object-cover h-72 w-72" alt=""${_scopeId2}></div>`);
              } else {
                return [
                  createVNode("div", { class: "bg-gray-300/20 max-w-sm rounded-sm overflow-hidden shadow-xl shadow-pink-600/40 m-7 p-4 transition duration-500 hover:scale-110" }, [
                    createVNode("h2", { class: "text-white text-4xl m-3 text-center" }, toDisplayString(empresa.nombre), 1),
                    createVNode("img", {
                      src: "https://pipartytime.com/storage/empresas/" + empresa.foto,
                      class: "mb-4 object-cover h-72 w-72",
                      alt: ""
                    }, null, 8, ["src"])
                  ])
                ];
              }
            }),
            _: 2
          }, _parent2, _scopeId));
          _push2(`</div>`);
        });
        _push2(`<!--]--></div></div>`);
      } else {
        return [
          createVNode("h1", { class: "text-white p-3 rounded-sm text-5xl mt-4 max-[1120px]:mx-0 max-[1120px]:text-4xl text-center mx-96" }, " LOCALES "),
          createVNode("div", { class: "hidden md:flex flex-col bg-black/70 rounded-br-xl float-left p-4" }, [
            createVNode("h1", { class: "text-white text-xl" }, "Ciudades"),
            createVNode("div", { class: "flex flex-col m-2 text-blue-400 items-center" }, [
              createVNode("label", { for: "sevilla" }, "Sevilla"),
              withDirectives(createVNode("input", {
                type: "checkbox",
                "onUpdate:modelValue": ($event) => $data.ciudades["sevilla"] = $event,
                id: "sevilla",
                onChange: $options.filtrar,
                name: "ciudad",
                class: "mr-2 mt-1 ml-1 rounded-full p-2"
              }, null, 40, ["onUpdate:modelValue", "onChange"]), [
                [vModelCheckbox, $data.ciudades["sevilla"]]
              ])
            ]),
            createVNode("div", { class: "flex flex-col m-2 text-pink-400 items-center" }, [
              createVNode("label", { for: "malaga" }, "Málaga"),
              withDirectives(createVNode("input", {
                type: "checkbox",
                "onUpdate:modelValue": ($event) => $data.ciudades["malaga"] = $event,
                id: "malaga",
                onChange: $options.filtrar,
                name: "ciudad",
                class: "mx-2 mt-1 rounded-full p-2"
              }, null, 40, ["onUpdate:modelValue", "onChange"]), [
                [vModelCheckbox, $data.ciudades["malaga"]]
              ])
            ]),
            createVNode("div", { class: "flex flex-col m-2 text-blue-400 items-center" }, [
              createVNode("label", { for: "cadiz" }, "Cádiz"),
              withDirectives(createVNode("input", {
                type: "checkbox",
                "onUpdate:modelValue": ($event) => $data.ciudades["cadiz"] = $event,
                id: "cadiz",
                onChange: $options.filtrar,
                name: "ciudad",
                class: "mx-2 mt-1 rounded-full p-2"
              }, null, 40, ["onUpdate:modelValue", "onChange"]), [
                [vModelCheckbox, $data.ciudades["cadiz"]]
              ])
            ]),
            createVNode("div", { class: "flex flex-col m-2 text-pink-400 items-center" }, [
              createVNode("label", { for: "granada" }, "Granada"),
              withDirectives(createVNode("input", {
                type: "checkbox",
                "onUpdate:modelValue": ($event) => $data.ciudades["granada"] = $event,
                id: "granada",
                onChange: $options.filtrar,
                name: "ciudad",
                class: "mx-2 mt-1 rounded-full p-2"
              }, null, 40, ["onUpdate:modelValue", "onChange"]), [
                [vModelCheckbox, $data.ciudades["granada"]]
              ])
            ]),
            createVNode("div", { class: "flex flex-col m-2 text-blue-400 items-center" }, [
              createVNode("label", { for: "cordoba" }, "Córdoba"),
              withDirectives(createVNode("input", {
                type: "checkbox",
                "onUpdate:modelValue": ($event) => $data.ciudades["cordoba"] = $event,
                id: "cordoba",
                onChange: $options.filtrar,
                name: "ciudad",
                class: "mx-2 mt-1 rounded-full p-2"
              }, null, 40, ["onUpdate:modelValue", "onChange"]), [
                [vModelCheckbox, $data.ciudades["cordoba"]]
              ])
            ]),
            createVNode("div", { class: "flex flex-col m-2 text-pink-400 items-center" }, [
              createVNode("label", { for: "almeria" }, "Almería"),
              withDirectives(createVNode("input", {
                type: "checkbox",
                "onUpdate:modelValue": ($event) => $data.ciudades["almeria"] = $event,
                id: "almeria",
                onChange: $options.filtrar,
                name: "ciudad",
                class: "mx-2 mt-1 rounded-full p-2"
              }, null, 40, ["onUpdate:modelValue", "onChange"]), [
                [vModelCheckbox, $data.ciudades["almeria"]]
              ])
            ]),
            createVNode("div", { class: "flex flex-col m-2 text-blue-400 items-center" }, [
              createVNode("label", { for: "huelva" }, "Huelva"),
              withDirectives(createVNode("input", {
                type: "checkbox",
                "onUpdate:modelValue": ($event) => $data.ciudades["huelva"] = $event,
                id: "huelva",
                onChange: $options.filtrar,
                name: "ciudad",
                class: "mx-2 mt-1 rounded-full p-2"
              }, null, 40, ["onUpdate:modelValue", "onChange"]), [
                [vModelCheckbox, $data.ciudades["huelva"]]
              ])
            ]),
            createVNode("div", { class: "flex flex-col m-2 text-pink-400 items-center" }, [
              createVNode("label", { for: "jaen" }, "Jaén"),
              withDirectives(createVNode("input", {
                type: "checkbox",
                "onUpdate:modelValue": ($event) => $data.ciudades["jaen"] = $event,
                id: "jaen",
                onChange: $options.filtrar,
                name: "ciudad",
                class: "mx-2 mt-1 rounded-full p-2"
              }, null, 40, ["onUpdate:modelValue", "onChange"]), [
                [vModelCheckbox, $data.ciudades["jaen"]]
              ])
            ])
          ]),
          createVNode("div", { class: "dropdown text-white" }, [
            createVNode("button", { class: "md:hidden dropbtn m-4" }, "Filtros"),
            createVNode("div", { class: "dropdown-content" }, [
              createVNode("div", { class: "flex flex-col bg-black/70 rounded-br-xl float-left p-4" }, [
                createVNode("h1", { class: "text-white text-xl" }, "Ciudades"),
                createVNode("div", { class: "m-2 text-blue-400 block inline-block" }, [
                  withDirectives(createVNode("input", {
                    type: "checkbox",
                    "onUpdate:modelValue": ($event) => $data.ciudades["sevilla"] = $event,
                    id: "sevilla",
                    onChange: $options.filtrar,
                    name: "ciudad",
                    class: "mx-2 mt-1 rounded-full p-1"
                  }, null, 40, ["onUpdate:modelValue", "onChange"]), [
                    [vModelCheckbox, $data.ciudades["sevilla"]]
                  ]),
                  createVNode("label", { for: "sevilla" }, "Sevilla")
                ]),
                createVNode("div", { class: "m-2 text-pink-400 block inline-block" }, [
                  withDirectives(createVNode("input", {
                    type: "checkbox",
                    "onUpdate:modelValue": ($event) => $data.ciudades["malaga"] = $event,
                    id: "malaga",
                    onChange: $options.filtrar,
                    name: "ciudad",
                    class: "mx-2 mt-1 rounded-full p-1"
                  }, null, 40, ["onUpdate:modelValue", "onChange"]), [
                    [vModelCheckbox, $data.ciudades["malaga"]]
                  ]),
                  createVNode("label", { for: "malaga" }, "Málaga")
                ]),
                createVNode("div", { class: "m-2 text-blue-400 block inline-block" }, [
                  withDirectives(createVNode("input", {
                    type: "checkbox",
                    "onUpdate:modelValue": ($event) => $data.ciudades["cadiz"] = $event,
                    id: "cadiz",
                    onChange: $options.filtrar,
                    name: "ciudad",
                    class: "mx-2 mt-1 rounded-full p-1"
                  }, null, 40, ["onUpdate:modelValue", "onChange"]), [
                    [vModelCheckbox, $data.ciudades["cadiz"]]
                  ]),
                  createVNode("label", { for: "cadiz" }, "Cádiz")
                ]),
                createVNode("div", { class: "m-2 text-pink-400 block inline-block" }, [
                  withDirectives(createVNode("input", {
                    type: "checkbox",
                    "onUpdate:modelValue": ($event) => $data.ciudades["granada"] = $event,
                    id: "granada",
                    onChange: $options.filtrar,
                    name: "ciudad",
                    class: "mx-2 mt-1 rounded-full p-1"
                  }, null, 40, ["onUpdate:modelValue", "onChange"]), [
                    [vModelCheckbox, $data.ciudades["granada"]]
                  ]),
                  createVNode("label", { for: "granada" }, "Granada")
                ]),
                createVNode("div", { class: "m-2 text-blue-400 block inline-block" }, [
                  withDirectives(createVNode("input", {
                    type: "checkbox",
                    "onUpdate:modelValue": ($event) => $data.ciudades["cordoba"] = $event,
                    id: "cordoba",
                    onChange: $options.filtrar,
                    name: "ciudad",
                    class: "mx-2 mt-1 rounded-full p-1"
                  }, null, 40, ["onUpdate:modelValue", "onChange"]), [
                    [vModelCheckbox, $data.ciudades["cordoba"]]
                  ]),
                  createVNode("label", { for: "cordoba" }, "Córdoba")
                ]),
                createVNode("div", { class: "m-2 text-pink-400 block inline-block" }, [
                  withDirectives(createVNode("input", {
                    type: "checkbox",
                    "onUpdate:modelValue": ($event) => $data.ciudades["almeria"] = $event,
                    id: "almeria",
                    onChange: $options.filtrar,
                    name: "ciudad",
                    class: "mx-2 mt-1 rounded-full p-1"
                  }, null, 40, ["onUpdate:modelValue", "onChange"]), [
                    [vModelCheckbox, $data.ciudades["almeria"]]
                  ]),
                  createVNode("label", { for: "almeria" }, "Almería")
                ]),
                createVNode("div", { class: "m-2 text-blue-400 block inline-block" }, [
                  withDirectives(createVNode("input", {
                    type: "checkbox",
                    "onUpdate:modelValue": ($event) => $data.ciudades["huelva"] = $event,
                    id: "huelva",
                    onChange: $options.filtrar,
                    name: "ciudad",
                    class: "mx-2 mt-1 rounded-full p-1"
                  }, null, 40, ["onUpdate:modelValue", "onChange"]), [
                    [vModelCheckbox, $data.ciudades["huelva"]]
                  ]),
                  createVNode("label", { for: "huelva" }, "Huelva")
                ]),
                createVNode("div", { class: "m-2 text-pink-400 block inline-block" }, [
                  withDirectives(createVNode("input", {
                    type: "checkbox",
                    "onUpdate:modelValue": ($event) => $data.ciudades["jaen"] = $event,
                    id: "jaen",
                    onChange: $options.filtrar,
                    name: "ciudad",
                    class: "mx-2 mt-1 rounded-full p-1"
                  }, null, 40, ["onUpdate:modelValue", "onChange"]), [
                    [vModelCheckbox, $data.ciudades["jaen"]]
                  ]),
                  createVNode("label", { for: "jaen" }, "Jaén")
                ])
              ])
            ])
          ]),
          createVNode("div", { class: "min-[450px]:grid place-items-center" }, [
            createVNode("div", { class: "flex flex-wrap justify-center min-[1400px]:grid min-[1400px]:grid-cols-4" }, [
              (openBlock(true), createBlock(Fragment, null, renderList($data.empresasFiltradas, (empresa) => {
                return openBlock(), createBlock("div", {
                  key: empresa.id
                }, [
                  createVNode(_component_nav_link, {
                    href: "perfil/" + empresa.id,
                    class: "no-underline"
                  }, {
                    default: withCtx(() => [
                      createVNode("div", { class: "bg-gray-300/20 max-w-sm rounded-sm overflow-hidden shadow-xl shadow-pink-600/40 m-7 p-4 transition duration-500 hover:scale-110" }, [
                        createVNode("h2", { class: "text-white text-4xl m-3 text-center" }, toDisplayString(empresa.nombre), 1),
                        createVNode("img", {
                          src: "https://pipartytime.com/storage/empresas/" + empresa.foto,
                          class: "mb-4 object-cover h-72 w-72",
                          alt: ""
                        }, null, 8, ["src"])
                      ])
                    ]),
                    _: 2
                  }, 1032, ["href"])
                ]);
              }), 128))
            ])
          ])
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</section>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/locales.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const locales = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  locales as default
};
