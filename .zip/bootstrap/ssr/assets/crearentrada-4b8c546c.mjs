import { mergeProps, withCtx, createVNode, withDirectives, openBlock, createBlock, Fragment, renderList, toDisplayString, vModelSelect, vModelText, withModifiers, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrRenderAttr, ssrInterpolate } from "vue/server-renderer";
import { L as Layout } from "./Layout-57e2f8e0.mjs";
import { Link } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./ResponsiveNavLink-c8aee0e1.mjs";
import Swal from "sweetalert2";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import "./logopng-0a2f9f34.mjs";
const crearentrada_vue_vue_type_style_index_0_scoped_3084f67b_lang = "";
const __default__ = {
  components: { NavLink: _sfc_main$1, Link },
  data() {
    return {
      showMenu: false,
      fiestas: [],
      empresas: [],
      fiesta_elegida: "",
      precio: "",
      consumiciones: "",
      tipo_entrada: "",
      aforo: ""
    };
  },
  mounted() {
    axios.get("/listarfiestas").then((response) => {
      this.fiestas = response.data;
    }).catch((error) => {
    });
    axios.get("/listarempresas").then((response) => {
      this.empresas = response.data;
    }).catch((error) => {
    });
  },
  methods: {
    validacion() {
      if (this.precio < 0 || this.precio == "") {
        return false;
      }
      if (this.aforo < 0 || this.aforo == "") {
        return false;
      }
      if (this.consumiciones < 0 || this.consumiciones == "") {
        return false;
      }
      return true;
    },
    formatdate(dateTimeString) {
      return dateTimeString.slice(0, 10);
    },
    enviar() {
      if (this.validacion()) {
        const formData = new FormData();
        formData.append("fiesta_elegida", this.fiesta_elegida);
        formData.append("precio", this.precio);
        formData.append("aforo", this.aforo);
        formData.append("consumiciones", this.consumiciones);
        formData.append("tipo", this.tipo_entrada);
        axios.post("/crearentradas", formData, {
          headers: {
            "Content-Type": "multipart/form-data"
          }
        }).then((response) => {
          this.showAlert();
        }).catch((error) => {
          this.showAlertError();
        });
      } else {
        this.showAlertValidacion();
      }
    },
    showAlert() {
      Swal.fire({
        title: "Entrada Creada",
        text: "Tu entrada ha sido creada exitosamente.",
        icon: "success",
        confirmButtonColor: "#1a202c"
      });
    },
    showAlertError() {
      Swal.fire({
        title: "Ha surgido un error",
        text: "Error inesperado. Intenta realizar esta operacion en unos minutos..",
        icon: "error",
        confirmButtonColor: "#1a202c"
      });
    },
    showAlertValidacion() {
      Swal.fire({
        title: "Error de validacion",
        text: "Los datos introducidos no son validos.",
        icon: "error",
        confirmButtonColor: "#1a202c"
      });
    }
  }
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  __name: "crearentrada",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "fondolog" }, _attrs))} data-v-3084f67b>`);
      _push(ssrRenderComponent(Layout, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<section class="flex justify-center mt-14" data-v-3084f67b${_scopeId}><div class="max-w-md justify-center text-white text-center mt-8 bg-gray-800/90 rounded-md p-12" data-v-3084f67b${_scopeId}><h1 class="text-3xl text-white" data-v-3084f67b${_scopeId}>Crear Entrada</h1><form action="" data-v-3084f67b${_scopeId}><div class="mt-8" data-v-3084f67b${_scopeId}><label for="Selecciona la fiesta:" data-v-3084f67b${_scopeId}>Fiesta:</label><br data-v-3084f67b${_scopeId}><div class="overflow-y-auto h-10 mx-4 break-words text-justify" data-v-3084f67b${_scopeId}><select required name="lenguajes" id="lang" class="p-1 text-gray-300 rounded-md bg-gray-700 h-10" data-v-3084f67b${_scopeId}><option value="" selected disabled data-v-3084f67b${_scopeId}>Seleccionar una opción</option><!--[-->`);
            ssrRenderList(_ctx.empresas, (e) => {
              _push2(`<optgroup class="text-pink-300"${ssrRenderAttr("label", e.nombre)} data-v-3084f67b${_scopeId}><!--[-->`);
              ssrRenderList(_ctx.fiestas.filter((f) => f.id_empresa == e.id && new Date(f.fecha) >= /* @__PURE__ */ new Date()), (f) => {
                _push2(`<option class="text-white m-40"${ssrRenderAttr("value", f.id)} data-v-3084f67b${_scopeId}>${ssrInterpolate(_ctx.formatdate(f.fecha))} -&gt; ${ssrInterpolate(f.musica.nombre)}</option>`);
              });
              _push2(`<!--]--></optgroup>`);
            });
            _push2(`<!--]--></select></div></div><div data-v-3084f67b${_scopeId}><label for="precio" data-v-3084f67b${_scopeId}>Precio</label><br data-v-3084f67b${_scopeId}><input class="w-48 h-8 rounded-md text-gray-300 bg-gray-600 text-center placeholder:text-gray-400 hover:scale-105 duration-200" type="number"${ssrRenderAttr("value", _ctx.precio)} data-v-3084f67b${_scopeId}></div><div data-v-3084f67b${_scopeId}><label for="consumiciones" data-v-3084f67b${_scopeId}>Consumiciones</label><br data-v-3084f67b${_scopeId}><input class="w-48 h-8 rounded-md text-gray-300 bg-gray-600 text-center placeholder:text-gray-400 hover:scale-105 duration-200" type="number"${ssrRenderAttr("value", _ctx.consumiciones)} data-v-3084f67b${_scopeId}></div><div class="mt-8" data-v-3084f67b${_scopeId}><label for="tipo_entrada" data-v-3084f67b${_scopeId}>Tipo</label><br data-v-3084f67b${_scopeId}><select name="tipo_entrada" required id="tipo_entrada" class="p-1 text-gray-300 rounded-md bg-gray-700" data-v-3084f67b${_scopeId}><option value="Basica" data-v-3084f67b${_scopeId}>Basica</option><option value="Normal" data-v-3084f67b${_scopeId}>Normal</option><option value="Premium" data-v-3084f67b${_scopeId}>Premium</option><option value="Reservado" data-v-3084f67b${_scopeId}>Reservado</option><option value="Especial" data-v-3084f67b${_scopeId}>Especial</option></select></div><div data-v-3084f67b${_scopeId}><label for="precio" data-v-3084f67b${_scopeId}>Nº Aforo</label><br data-v-3084f67b${_scopeId}><input class="w-48 h-8 rounded-md text-gray-300 bg-gray-600 text-center placeholder:text-gray-400 hover:scale-105 duration-200" type="number"${ssrRenderAttr("value", _ctx.aforo)} data-v-3084f67b${_scopeId}></div><button class="decoration-0 m-4 px-3 py-2 border-2 rounded-md bg-pink-900/80 hover:bg-pink-800/80 text-white hover:scale-110 duration-200" data-v-3084f67b${_scopeId}>Crear Entrada</button></form></div></section>`);
          } else {
            return [
              createVNode("section", { class: "flex justify-center mt-14" }, [
                createVNode("div", { class: "max-w-md justify-center text-white text-center mt-8 bg-gray-800/90 rounded-md p-12" }, [
                  createVNode("h1", { class: "text-3xl text-white" }, "Crear Entrada"),
                  createVNode("form", { action: "" }, [
                    createVNode("div", { class: "mt-8" }, [
                      createVNode("label", { for: "Selecciona la fiesta:" }, "Fiesta:"),
                      createVNode("br"),
                      createVNode("div", { class: "overflow-y-auto h-10 mx-4 break-words text-justify" }, [
                        withDirectives(createVNode("select", {
                          required: "",
                          "onUpdate:modelValue": ($event) => _ctx.fiesta_elegida = $event,
                          name: "lenguajes",
                          id: "lang",
                          class: "p-1 text-gray-300 rounded-md bg-gray-700 h-10"
                        }, [
                          createVNode("option", {
                            value: "",
                            selected: "",
                            disabled: ""
                          }, "Seleccionar una opción"),
                          (openBlock(true), createBlock(Fragment, null, renderList(_ctx.empresas, (e) => {
                            return openBlock(), createBlock("optgroup", {
                              key: e.id,
                              class: "text-pink-300",
                              label: e.nombre
                            }, [
                              (openBlock(true), createBlock(Fragment, null, renderList(_ctx.fiestas.filter((f) => f.id_empresa == e.id && new Date(f.fecha) >= /* @__PURE__ */ new Date()), (f) => {
                                return openBlock(), createBlock("option", {
                                  class: "text-white m-40",
                                  key: f.id,
                                  value: f.id
                                }, toDisplayString(_ctx.formatdate(f.fecha)) + " -> " + toDisplayString(f.musica.nombre), 9, ["value"]);
                              }), 128))
                            ], 8, ["label"]);
                          }), 128))
                        ], 8, ["onUpdate:modelValue"]), [
                          [vModelSelect, _ctx.fiesta_elegida]
                        ])
                      ])
                    ]),
                    createVNode("div", null, [
                      createVNode("label", { for: "precio" }, "Precio"),
                      createVNode("br"),
                      withDirectives(createVNode("input", {
                        class: "w-48 h-8 rounded-md text-gray-300 bg-gray-600 text-center placeholder:text-gray-400 hover:scale-105 duration-200",
                        type: "number",
                        "onUpdate:modelValue": ($event) => _ctx.precio = $event
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, _ctx.precio]
                      ])
                    ]),
                    createVNode("div", null, [
                      createVNode("label", { for: "consumiciones" }, "Consumiciones"),
                      createVNode("br"),
                      withDirectives(createVNode("input", {
                        class: "w-48 h-8 rounded-md text-gray-300 bg-gray-600 text-center placeholder:text-gray-400 hover:scale-105 duration-200",
                        type: "number",
                        "onUpdate:modelValue": ($event) => _ctx.consumiciones = $event
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, _ctx.consumiciones]
                      ])
                    ]),
                    createVNode("div", { class: "mt-8" }, [
                      createVNode("label", { for: "tipo_entrada" }, "Tipo"),
                      createVNode("br"),
                      withDirectives(createVNode("select", {
                        name: "tipo_entrada",
                        required: "",
                        "onUpdate:modelValue": ($event) => _ctx.tipo_entrada = $event,
                        id: "tipo_entrada",
                        class: "p-1 text-gray-300 rounded-md bg-gray-700"
                      }, [
                        createVNode("option", { value: "Basica" }, "Basica"),
                        createVNode("option", { value: "Normal" }, "Normal"),
                        createVNode("option", { value: "Premium" }, "Premium"),
                        createVNode("option", { value: "Reservado" }, "Reservado"),
                        createVNode("option", { value: "Especial" }, "Especial")
                      ], 8, ["onUpdate:modelValue"]), [
                        [vModelSelect, _ctx.tipo_entrada]
                      ])
                    ]),
                    createVNode("div", null, [
                      createVNode("label", { for: "precio" }, "Nº Aforo"),
                      createVNode("br"),
                      withDirectives(createVNode("input", {
                        class: "w-48 h-8 rounded-md text-gray-300 bg-gray-600 text-center placeholder:text-gray-400 hover:scale-105 duration-200",
                        type: "number",
                        "onUpdate:modelValue": ($event) => _ctx.aforo = $event
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, _ctx.aforo]
                      ])
                    ]),
                    createVNode("button", {
                      class: "decoration-0 m-4 px-3 py-2 border-2 rounded-md bg-pink-900/80 hover:bg-pink-800/80 text-white hover:scale-110 duration-200",
                      onClick: withModifiers(_ctx.enviar, ["prevent"])
                    }, "Crear Entrada", 8, ["onClick"])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</section>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/crearentrada.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const crearentrada = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-3084f67b"]]);
export {
  crearentrada as default
};
