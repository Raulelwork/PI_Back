import { Link } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./ResponsiveNavLink-c8aee0e1.mjs";
import { L as Layout } from "./Layout-57e2f8e0.mjs";
import { ref, watchEffect, resolveComponent, mergeProps, withCtx, createTextVNode, createVNode, openBlock, createBlock, Fragment, renderList, toDisplayString, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderClass, ssrRenderAttr } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import "./logopng-0a2f9f34.mjs";
const _imports_0 = "/build/assets/borrar-9dc2ce75.png";
const _sfc_main = {
  components: { NavLink: _sfc_main$1, Link, Layout, ref },
  data() {
    return {
      showMenu: false,
      fiestas: [],
      entradas: [],
      empresas: [],
      fiesta_elegida: "",
      entrada_elegida: "",
      currentPage: 1,
      currentPageEntrada: 1,
      currentPageEmpresa: 1,
      itemsPerPage: 5
    };
  },
  methods: {
    orderByDate: function(fiestas) {
      return fiestas.sort(function(a, b) {
        return new Date(a.fecha) - new Date(b.fecha);
      });
    },
    previousPage() {
      if (this.currentPage > 1) {
        this.currentPage--;
      }
    },
    //boton siguiente de la paginacion tabla fiestas
    nextPage() {
      if (this.currentPage < this.totalPages) {
        this.currentPage++;
      }
    },
    goToPage(pageNumber) {
      this.currentPage = pageNumber;
    },
    previousPageEntrada() {
      if (this.currentPageEntrada > 1) {
        this.currentPageEntrada--;
      }
    },
    //boton siguiente de la paginacion tabla entradas
    nextPageEntrada() {
      if (this.currentPageEntrada < this.totalPagesEntrada) {
        this.currentPageEntrada++;
      }
    },
    goToPageEntrada(pageNumber) {
      this.currentPageEntrada = pageNumber;
    },
    previousPageEmpresa() {
      if (this.currentPageEmpresa > 1) {
        this.currentPageEmpresa--;
      }
    },
    //boton siguiente de la paginacion tabla empresas
    nextPageEmpresa() {
      if (this.currentPageEmpresa < this.totalPagesEmpresa) {
        this.currentPageEmpresa++;
      }
    },
    goToPageEmpresa(pageNumber) {
      this.currentPageEmpresa = pageNumber;
    },
    eliminarentrada(id_entrada) {
      axios.post("/eliminarentrada", {
        "id_entrada": id_entrada
      }).then((response) => {
        for (var i = 0; i < this.entradas.length; i++) {
          if (this.entradas[i].id == id_entrada) {
            this.entradas.splice(i, 1);
          }
        }
      }).catch((error) => {
      });
    },
    eliminarfiesta(id_fiesta) {
      axios.post("/eliminarfiesta", {
        "id_fiesta": id_fiesta
      }).then((response) => {
        for (var i = 0; i < this.fiestas.length; i++) {
          if (this.fiestas[i].id == id_fiesta) {
            this.fiestas.splice(i, 1);
          }
        }
      }).catch((error) => {
      });
    }
  },
  computed: {
    paginatedFiestas() {
      const startIndex = (this.currentPage - 1) * this.itemsPerPage;
      const endIndex = startIndex + this.itemsPerPage;
      return this.fiestas.slice(startIndex, endIndex);
    },
    paginatedEntradas() {
      const startIndex = (this.currentPageEntrada - 1) * this.itemsPerPage;
      const endIndex = startIndex + this.itemsPerPage;
      return this.entradas.slice(startIndex, endIndex);
    },
    paginatedEmpresas() {
      const startIndex = (this.currentPageEmpresa - 1) * this.itemsPerPage;
      const endIndex = startIndex + this.itemsPerPage;
      return this.empresas.slice(startIndex, endIndex);
    },
    //total de pagina 
    totalPages() {
      return Math.ceil(this.fiestas.length / this.itemsPerPage);
    },
    totalPagesEntrada() {
      return Math.ceil(this.entradas.length / this.itemsPerPage);
    },
    totalPagesEmpresa() {
      return Math.ceil(this.empresas.length / this.itemsPerPage);
    }
  },
  setup() {
    const fiestas = ref([]);
    const entradas = ref([]);
    const empresas = ref([]);
    watchEffect(() => {
      axios.get("/listarfiestasad").then((response) => {
        fiestas.value = response.data;
      }).catch((error) => {
      });
      axios.get("/listarentradasad").then((response) => {
        entradas.value = response.data;
      }).catch((error) => {
      });
      axios.get("/listarempresas").then((response) => {
        empresas.value = response.data;
      }).catch((error) => {
      });
    });
    return {
      fiestas,
      entradas,
      empresas
    };
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Layout = resolveComponent("Layout");
  const _component_NavLink = resolveComponent("NavLink");
  _push(`<section${ssrRenderAttrs(mergeProps({ class: "bg-gray-300" }, _attrs))}>`);
  if (_ctx.$page.props.auth.user.tipo == "empresa") {
    _push(ssrRenderComponent(_component_Layout, null, {
      default: withCtx((_, _push2, _parent2, _scopeId) => {
        if (_push2) {
          _push2(`<div${_scopeId}><h1 class="text-4xl text-center mt-12 text-blue-600"${_scopeId}>ADMINISTRACION</h1></div><div class="flex justify-center mt-4 text-gray-600"${_scopeId}>`);
          _push2(ssrRenderComponent(_component_NavLink, {
            href: "/crearempresa",
            class: "hover:text-gray-300 m-4"
          }, {
            default: withCtx((_2, _push3, _parent3, _scopeId2) => {
              if (_push3) {
                _push3(`Añadir Empresa`);
              } else {
                return [
                  createTextVNode("Añadir Empresa")
                ];
              }
            }),
            _: 1
          }, _parent2, _scopeId));
          _push2(ssrRenderComponent(_component_NavLink, {
            href: "/crearfiesta",
            class: "hover:text-gray-300 m-4"
          }, {
            default: withCtx((_2, _push3, _parent3, _scopeId2) => {
              if (_push3) {
                _push3(`Crear Fiesta`);
              } else {
                return [
                  createTextVNode("Crear Fiesta")
                ];
              }
            }),
            _: 1
          }, _parent2, _scopeId));
          _push2(ssrRenderComponent(_component_NavLink, {
            href: "/crearent",
            class: "hover:text-gray-300 m-4"
          }, {
            default: withCtx((_2, _push3, _parent3, _scopeId2) => {
              if (_push3) {
                _push3(`Crear Entrada`);
              } else {
                return [
                  createTextVNode("Crear Entrada")
                ];
              }
            }),
            _: 1
          }, _parent2, _scopeId));
          _push2(ssrRenderComponent(_component_NavLink, {
            href: "/editafiesta",
            class: "hover:text-gray-300 m-4"
          }, {
            default: withCtx((_2, _push3, _parent3, _scopeId2) => {
              if (_push3) {
                _push3(`Editar Fiesta`);
              } else {
                return [
                  createTextVNode("Editar Fiesta")
                ];
              }
            }),
            _: 1
          }, _parent2, _scopeId));
          _push2(`</div><div class="flex justify-center items-center flex-col text-center text-black min-[600px]:mx-48 my-12"${_scopeId}><h1 class="text-3xl"${_scopeId}>EMPRESAS</h1><table class="min-[600px]:min-w-full border-collapse block md:table"${_scopeId}><thead class="block md:table-header-group"${_scopeId}><tr class="border border-grey-500 md:border-none block md:table-row absolute -top-full md:top-auto -left-full md:left-auto md:relative"${_scopeId}><td class="th"${_scopeId}>Nombre Empresa</td><td class="th"${_scopeId}>Ciudad</td><td class="th"${_scopeId}>Lugar</td><td class="th"${_scopeId}>Cif</td></tr></thead><!--[-->`);
          ssrRenderList($options.paginatedEmpresas, (empresa, index) => {
            _push2(`<tbody class="block md:table-row-group max-[765px]:border-2 border-black mb-1"${_scopeId}><tr${_scopeId}><td class="td"${_scopeId}><span class="mobile"${_scopeId}>Nombre</span> ${ssrInterpolate(empresa.nombre)}</td><td class="td"${_scopeId}><span class="mobile"${_scopeId}>Ciudad</span> ${ssrInterpolate(empresa.ubicacion)}</td><td class="td"${_scopeId}><span class="mobile"${_scopeId}>Lugar</span> ${ssrInterpolate(empresa.lugar)}</td><td class="td"${_scopeId}><span class="mobile"${_scopeId}>Cif</span>${ssrInterpolate(empresa.cif)}</td></tr></tbody>`);
          });
          _push2(`<!--]--></table><div class="flex justify-center mt-4"${_scopeId}><nav${_scopeId}><ul class="flex justify-center list-none p-0"${_scopeId}><li class="${ssrRenderClass([{ disabled: $data.currentPageEmpresa === 1 }, "pageitem"])}"${_scopeId}><button class="pagelink"${_scopeId}>Anterior</button></li><!--[-->`);
          ssrRenderList($options.totalPagesEmpresa, (pageNumber) => {
            _push2(`<li class="${ssrRenderClass([{ active: pageNumber === $data.currentPageEmpresa }, "pageitem"])}"${_scopeId}><button class="pagelink"${_scopeId}>${ssrInterpolate(pageNumber)}</button></li>`);
          });
          _push2(`<!--]--><li class="${ssrRenderClass([{ disabled: $data.currentPageEmpresa === $options.totalPagesEmpresa }, "pageitem"])}"${_scopeId}><button class="pagelink"${_scopeId}>Siguiente</button></li></ul></nav></div></div><div class="flex justify-center items-center flex-col text-center text-black min-[600px]:mx-48"${_scopeId}><h1 class="text-3xl"${_scopeId}>FIESTAS</h1><table class="min-[600px]:min-w-full border-collapse block md:table"${_scopeId}><thead class="block md:table-header-group"${_scopeId}><tr class="border border-grey-500 md:border-none block md:table-row absolute -top-full md:top-auto -left-full md:left-auto md:relative"${_scopeId}><td class="th"${_scopeId}>Nombre Empresa</td><td class="th"${_scopeId}>Musica</td><td class="th"${_scopeId}>Tematica</td><td class="th"${_scopeId}>Fecha</td><td class="th"${_scopeId}>Eliminar</td></tr></thead><!--[-->`);
          ssrRenderList($options.orderByDate($options.paginatedFiestas), (f, index) => {
            _push2(`<tbody class="block md:table-row-group max-[765px]:border-2 border-black mb-1"${_scopeId}><tr${_scopeId}><td class="td"${_scopeId}><span class="mobile"${_scopeId}>Nombre</span> ${ssrInterpolate(f.empresa.nombre)}</td><td class="td"${_scopeId}><span class="mobile"${_scopeId}>Musica</span> ${ssrInterpolate(f.musica.nombre)}</td><td class="td"${_scopeId}><span class="mobile"${_scopeId}>Tematica</span> ${ssrInterpolate(f.tematica.nombre)}</td><td class="td"${_scopeId}><span class="mobile"${_scopeId}>Fecha</span>${ssrInterpolate(f.fecha)}</td><td class="td"${_scopeId}><button${_scopeId}><img${ssrRenderAttr("src", _imports_0)} class="w-6 m-auto" alt=""${_scopeId}></button></td></tr></tbody>`);
          });
          _push2(`<!--]--></table><div class="flex justify-center mt-4"${_scopeId}><nav${_scopeId}><ul class="flex justify-center list-none p-0"${_scopeId}><li class="${ssrRenderClass([{ disabled: $data.currentPage === 1 }, "pageitem"])}"${_scopeId}><button class="pagelink"${_scopeId}>Anterior</button></li><!--[-->`);
          ssrRenderList($options.totalPages, (pageNumber) => {
            _push2(`<li class="${ssrRenderClass([{ active: pageNumber === $data.currentPage }, "pageitem"])}"${_scopeId}><button class="pagelink"${_scopeId}>${ssrInterpolate(pageNumber)}</button></li>`);
          });
          _push2(`<!--]--><li class="${ssrRenderClass([{ disabled: $data.currentPage === $options.totalPages }, "pageitem"])}"${_scopeId}><button class="pagelink"${_scopeId}>Siguiente</button></li></ul></nav></div></div><div class="my-12 flex justify-center items-center flex-col text-center text-black min-[600px]:mx-48"${_scopeId}><h1 class="text-3xl"${_scopeId}>ENTRADAS</h1><table class="min-[600px]:min-w-full border-collapse block md:table"${_scopeId}><thead class="block md:table-header-group"${_scopeId}><tr class="border border-grey-500 md:border-none block md:table-row absolute -top-full md:top-auto -left-full md:left-auto md:relative"${_scopeId}><td class="th"${_scopeId}>Tipo</td><td class="th"${_scopeId}>Precio</td><td class="th"${_scopeId}>Consumicion</td><td class="th"${_scopeId}>Entradas Restantes</td><td class="th"${_scopeId}>Entradas Iniciales</td><td class="th"${_scopeId}>Fecha Fiesta</td><td class="th"${_scopeId}>Empresa</td><td class="th"${_scopeId}>Eliminar</td></tr></thead><!--[-->`);
          ssrRenderList($options.paginatedEntradas, (entrada, index) => {
            _push2(`<tbody class="block md:table-row-group max-[765px]:border-2 border-black mb-1"${_scopeId}><tr${_scopeId}><td class="td"${_scopeId}><span class="mobile"${_scopeId}>Tipo</span> ${ssrInterpolate(entrada.tipo)}</td><td class="td"${_scopeId}><span class="mobile"${_scopeId}>Precio</span> ${ssrInterpolate(entrada.precio)}</td><td class="td"${_scopeId}><span class="mobile"${_scopeId}>Copas</span> ${ssrInterpolate(entrada.consumiciones)}</td><td class="td"${_scopeId}><span class="mobile"${_scopeId}>Copas</span> ${ssrInterpolate(entrada.aforo)}</td><td class="td"${_scopeId}><span class="mobile"${_scopeId}>Copas</span> ${ssrInterpolate(entrada.aforoinicial)}</td><td class="td"${_scopeId}><span class="mobile"${_scopeId}>Fecha</span> ${ssrInterpolate(entrada.fecha)}</td><td class="td"${_scopeId}><span class="mobile"${_scopeId}>Empresa</span> ${ssrInterpolate(entrada.empresa)}</td><td class="td"${_scopeId}><button${_scopeId}><img${ssrRenderAttr("src", _imports_0)} class="w-6 m-auto" alt=""${_scopeId}></button></td></tr></tbody>`);
          });
          _push2(`<!--]--></table><div class="flex justify-center mt-4"${_scopeId}><nav${_scopeId}><ul class="flex justify-center list-none p-0"${_scopeId}><li class="${ssrRenderClass([{ disabled: $data.currentPageEntrada === 1 }, "pageitem"])}"${_scopeId}><button class="pagelink"${_scopeId}>Anterior</button></li><!--[-->`);
          ssrRenderList($options.totalPagesEntrada, (pageNumber) => {
            _push2(`<li class="${ssrRenderClass([{ active: pageNumber === $data.currentPageEntrada }, "pageitem"])}"${_scopeId}><button class="pagelink"${_scopeId}>${ssrInterpolate(pageNumber)}</button></li>`);
          });
          _push2(`<!--]--><li class="${ssrRenderClass([{ disabled: $data.currentPageEntrada === $options.totalPagesEntrada }, "pageitem"])}"${_scopeId}><button class="pagelink"${_scopeId}>Siguiente</button></li></ul></nav></div></div>`);
        } else {
          return [
            createVNode("div", null, [
              createVNode("h1", { class: "text-4xl text-center mt-12 text-blue-600" }, "ADMINISTRACION")
            ]),
            createVNode("div", { class: "flex justify-center mt-4 text-gray-600" }, [
              createVNode(_component_NavLink, {
                href: "/crearempresa",
                class: "hover:text-gray-300 m-4"
              }, {
                default: withCtx(() => [
                  createTextVNode("Añadir Empresa")
                ]),
                _: 1
              }),
              createVNode(_component_NavLink, {
                href: "/crearfiesta",
                class: "hover:text-gray-300 m-4"
              }, {
                default: withCtx(() => [
                  createTextVNode("Crear Fiesta")
                ]),
                _: 1
              }),
              createVNode(_component_NavLink, {
                href: "/crearent",
                class: "hover:text-gray-300 m-4"
              }, {
                default: withCtx(() => [
                  createTextVNode("Crear Entrada")
                ]),
                _: 1
              }),
              createVNode(_component_NavLink, {
                href: "/editafiesta",
                class: "hover:text-gray-300 m-4"
              }, {
                default: withCtx(() => [
                  createTextVNode("Editar Fiesta")
                ]),
                _: 1
              })
            ]),
            createVNode("div", { class: "flex justify-center items-center flex-col text-center text-black min-[600px]:mx-48 my-12" }, [
              createVNode("h1", { class: "text-3xl" }, "EMPRESAS"),
              createVNode("table", { class: "min-[600px]:min-w-full border-collapse block md:table" }, [
                createVNode("thead", { class: "block md:table-header-group" }, [
                  createVNode("tr", { class: "border border-grey-500 md:border-none block md:table-row absolute -top-full md:top-auto -left-full md:left-auto md:relative" }, [
                    createVNode("td", { class: "th" }, "Nombre Empresa"),
                    createVNode("td", { class: "th" }, "Ciudad"),
                    createVNode("td", { class: "th" }, "Lugar"),
                    createVNode("td", { class: "th" }, "Cif")
                  ])
                ]),
                (openBlock(true), createBlock(Fragment, null, renderList($options.paginatedEmpresas, (empresa, index) => {
                  return openBlock(), createBlock("tbody", {
                    class: "block md:table-row-group max-[765px]:border-2 border-black mb-1",
                    key: empresa.id
                  }, [
                    createVNode("tr", null, [
                      createVNode("td", { class: "td" }, [
                        createVNode("span", { class: "mobile" }, "Nombre"),
                        createTextVNode(" " + toDisplayString(empresa.nombre), 1)
                      ]),
                      createVNode("td", { class: "td" }, [
                        createVNode("span", { class: "mobile" }, "Ciudad"),
                        createTextVNode(" " + toDisplayString(empresa.ubicacion), 1)
                      ]),
                      createVNode("td", { class: "td" }, [
                        createVNode("span", { class: "mobile" }, "Lugar"),
                        createTextVNode(" " + toDisplayString(empresa.lugar), 1)
                      ]),
                      createVNode("td", { class: "td" }, [
                        createVNode("span", { class: "mobile" }, "Cif"),
                        createTextVNode(toDisplayString(empresa.cif), 1)
                      ])
                    ])
                  ]);
                }), 128))
              ]),
              createVNode("div", { class: "flex justify-center mt-4" }, [
                createVNode("nav", null, [
                  createVNode("ul", { class: "flex justify-center list-none p-0" }, [
                    createVNode("li", {
                      class: ["pageitem", { disabled: $data.currentPageEmpresa === 1 }]
                    }, [
                      createVNode("button", {
                        class: "pagelink",
                        onClick: $options.previousPageEmpresa
                      }, "Anterior", 8, ["onClick"])
                    ], 2),
                    (openBlock(true), createBlock(Fragment, null, renderList($options.totalPagesEmpresa, (pageNumber) => {
                      return openBlock(), createBlock("li", {
                        class: ["pageitem", { active: pageNumber === $data.currentPageEmpresa }],
                        key: pageNumber
                      }, [
                        createVNode("button", {
                          class: "pagelink",
                          onClick: ($event) => $options.goToPageEmpresa(pageNumber)
                        }, toDisplayString(pageNumber), 9, ["onClick"])
                      ], 2);
                    }), 128)),
                    createVNode("li", {
                      class: ["pageitem", { disabled: $data.currentPageEmpresa === $options.totalPagesEmpresa }]
                    }, [
                      createVNode("button", {
                        class: "pagelink",
                        onClick: $options.nextPageEmpresa
                      }, "Siguiente", 8, ["onClick"])
                    ], 2)
                  ])
                ])
              ])
            ]),
            createVNode("div", { class: "flex justify-center items-center flex-col text-center text-black min-[600px]:mx-48" }, [
              createVNode("h1", { class: "text-3xl" }, "FIESTAS"),
              createVNode("table", { class: "min-[600px]:min-w-full border-collapse block md:table" }, [
                createVNode("thead", { class: "block md:table-header-group" }, [
                  createVNode("tr", { class: "border border-grey-500 md:border-none block md:table-row absolute -top-full md:top-auto -left-full md:left-auto md:relative" }, [
                    createVNode("td", { class: "th" }, "Nombre Empresa"),
                    createVNode("td", { class: "th" }, "Musica"),
                    createVNode("td", { class: "th" }, "Tematica"),
                    createVNode("td", { class: "th" }, "Fecha"),
                    createVNode("td", { class: "th" }, "Eliminar")
                  ])
                ]),
                (openBlock(true), createBlock(Fragment, null, renderList($options.orderByDate($options.paginatedFiestas), (f, index) => {
                  return openBlock(), createBlock("tbody", {
                    class: "block md:table-row-group max-[765px]:border-2 border-black mb-1",
                    key: f.id
                  }, [
                    createVNode("tr", null, [
                      createVNode("td", { class: "td" }, [
                        createVNode("span", { class: "mobile" }, "Nombre"),
                        createTextVNode(" " + toDisplayString(f.empresa.nombre), 1)
                      ]),
                      createVNode("td", { class: "td" }, [
                        createVNode("span", { class: "mobile" }, "Musica"),
                        createTextVNode(" " + toDisplayString(f.musica.nombre), 1)
                      ]),
                      createVNode("td", { class: "td" }, [
                        createVNode("span", { class: "mobile" }, "Tematica"),
                        createTextVNode(" " + toDisplayString(f.tematica.nombre), 1)
                      ]),
                      createVNode("td", { class: "td" }, [
                        createVNode("span", { class: "mobile" }, "Fecha"),
                        createTextVNode(toDisplayString(f.fecha), 1)
                      ]),
                      createVNode("td", { class: "td" }, [
                        createVNode("button", {
                          onClick: ($event) => $options.eliminarfiesta(f.id)
                        }, [
                          createVNode("img", {
                            src: _imports_0,
                            class: "w-6 m-auto",
                            alt: ""
                          })
                        ], 8, ["onClick"])
                      ])
                    ])
                  ]);
                }), 128))
              ]),
              createVNode("div", { class: "flex justify-center mt-4" }, [
                createVNode("nav", null, [
                  createVNode("ul", { class: "flex justify-center list-none p-0" }, [
                    createVNode("li", {
                      class: ["pageitem", { disabled: $data.currentPage === 1 }]
                    }, [
                      createVNode("button", {
                        class: "pagelink",
                        onClick: $options.previousPage
                      }, "Anterior", 8, ["onClick"])
                    ], 2),
                    (openBlock(true), createBlock(Fragment, null, renderList($options.totalPages, (pageNumber) => {
                      return openBlock(), createBlock("li", {
                        class: ["pageitem", { active: pageNumber === $data.currentPage }],
                        key: pageNumber
                      }, [
                        createVNode("button", {
                          class: "pagelink",
                          onClick: ($event) => $options.goToPage(pageNumber)
                        }, toDisplayString(pageNumber), 9, ["onClick"])
                      ], 2);
                    }), 128)),
                    createVNode("li", {
                      class: ["pageitem", { disabled: $data.currentPage === $options.totalPages }]
                    }, [
                      createVNode("button", {
                        class: "pagelink",
                        onClick: $options.nextPage
                      }, "Siguiente", 8, ["onClick"])
                    ], 2)
                  ])
                ])
              ])
            ]),
            createVNode("div", { class: "my-12 flex justify-center items-center flex-col text-center text-black min-[600px]:mx-48" }, [
              createVNode("h1", { class: "text-3xl" }, "ENTRADAS"),
              createVNode("table", { class: "min-[600px]:min-w-full border-collapse block md:table" }, [
                createVNode("thead", { class: "block md:table-header-group" }, [
                  createVNode("tr", { class: "border border-grey-500 md:border-none block md:table-row absolute -top-full md:top-auto -left-full md:left-auto md:relative" }, [
                    createVNode("td", { class: "th" }, "Tipo"),
                    createVNode("td", { class: "th" }, "Precio"),
                    createVNode("td", { class: "th" }, "Consumicion"),
                    createVNode("td", { class: "th" }, "Entradas Restantes"),
                    createVNode("td", { class: "th" }, "Entradas Iniciales"),
                    createVNode("td", { class: "th" }, "Fecha Fiesta"),
                    createVNode("td", { class: "th" }, "Empresa"),
                    createVNode("td", { class: "th" }, "Eliminar")
                  ])
                ]),
                (openBlock(true), createBlock(Fragment, null, renderList($options.paginatedEntradas, (entrada, index) => {
                  return openBlock(), createBlock("tbody", {
                    class: "block md:table-row-group max-[765px]:border-2 border-black mb-1",
                    key: entrada.id
                  }, [
                    createVNode("tr", null, [
                      createVNode("td", { class: "td" }, [
                        createVNode("span", { class: "mobile" }, "Tipo"),
                        createTextVNode(" " + toDisplayString(entrada.tipo), 1)
                      ]),
                      createVNode("td", { class: "td" }, [
                        createVNode("span", { class: "mobile" }, "Precio"),
                        createTextVNode(" " + toDisplayString(entrada.precio), 1)
                      ]),
                      createVNode("td", { class: "td" }, [
                        createVNode("span", { class: "mobile" }, "Copas"),
                        createTextVNode(" " + toDisplayString(entrada.consumiciones), 1)
                      ]),
                      createVNode("td", { class: "td" }, [
                        createVNode("span", { class: "mobile" }, "Copas"),
                        createTextVNode(" " + toDisplayString(entrada.aforo), 1)
                      ]),
                      createVNode("td", { class: "td" }, [
                        createVNode("span", { class: "mobile" }, "Copas"),
                        createTextVNode(" " + toDisplayString(entrada.aforoinicial), 1)
                      ]),
                      createVNode("td", { class: "td" }, [
                        createVNode("span", { class: "mobile" }, "Fecha"),
                        createTextVNode(" " + toDisplayString(entrada.fecha), 1)
                      ]),
                      createVNode("td", { class: "td" }, [
                        createVNode("span", { class: "mobile" }, "Empresa"),
                        createTextVNode(" " + toDisplayString(entrada.empresa), 1)
                      ]),
                      createVNode("td", { class: "td" }, [
                        createVNode("button", {
                          onClick: ($event) => $options.eliminarentrada(entrada.id)
                        }, [
                          createVNode("img", {
                            src: _imports_0,
                            class: "w-6 m-auto",
                            alt: ""
                          })
                        ], 8, ["onClick"])
                      ])
                    ])
                  ]);
                }), 128))
              ]),
              createVNode("div", { class: "flex justify-center mt-4" }, [
                createVNode("nav", null, [
                  createVNode("ul", { class: "flex justify-center list-none p-0" }, [
                    createVNode("li", {
                      class: ["pageitem", { disabled: $data.currentPageEntrada === 1 }]
                    }, [
                      createVNode("button", {
                        class: "pagelink",
                        onClick: $options.previousPageEntrada
                      }, "Anterior", 8, ["onClick"])
                    ], 2),
                    (openBlock(true), createBlock(Fragment, null, renderList($options.totalPagesEntrada, (pageNumber) => {
                      return openBlock(), createBlock("li", {
                        class: ["pageitem", { active: pageNumber === $data.currentPageEntrada }],
                        key: pageNumber
                      }, [
                        createVNode("button", {
                          class: "pagelink",
                          onClick: ($event) => $options.goToPageEntrada(pageNumber)
                        }, toDisplayString(pageNumber), 9, ["onClick"])
                      ], 2);
                    }), 128)),
                    createVNode("li", {
                      class: ["pageitem", { disabled: $data.currentPageEntrada === $options.totalPagesEntrada }]
                    }, [
                      createVNode("button", {
                        class: "pagelink",
                        onClick: $options.nextPageEntrada
                      }, "Siguiente", 8, ["onClick"])
                    ], 2)
                  ])
                ])
              ])
            ])
          ];
        }
      }),
      _: 1
    }, _parent));
  } else {
    _push(`<!---->`);
  }
  _push(`</section>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/administracion.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const administracion = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  administracion as default
};
